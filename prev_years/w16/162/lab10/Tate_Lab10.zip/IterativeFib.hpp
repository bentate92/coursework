
/**********************************************************************
 ** Program Filename: IterativeFib.hpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Declaration of the IterativeFib class, which will
 **   use iteration to calculate a given number in the Fibonacci sequence
 ** Input: None
 ** Output: None
 *********************************************************************/

#ifndef ITERATIVEFIB_HPP
#define ITERATIVEFIB_HPP

#include <iostream>
using namespace std;

/*
 * Creation of IterativeFib class
 * See IterativeFib.cpp for full descriptions of functions and data members.
 */
class IterativeFib {
  private:
    int n;

  public:
    IterativeFib(int);
    unsigned long Fib(int);
    void printFib();
};

#endif

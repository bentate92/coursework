
/**********************************************************************
 ** Program Filename: IterativeFib.cpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Implementation of the IterativeFib class, described in
 **   IterativeFib.hpp
 ** Input: Responses to prompts
 ** Output: Various prompts
 *********************************************************************/

#include "IterativeFib.hpp"
using namespace std;

/**********************************************************************
 ** Function: Constructor -- IterativeFib()
 ** Description: Assigns num to n and calls printFib()
 ** Parameters: Int representing place in the Fibonacci sequence to find 
 **   the value of 
 ** Pre-Conditions: num must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
IterativeFib::IterativeFib(int num){
  n = num;
  printFib();
}

/**********************************************************************
 ** Function: Fib()
 ** Source: Modified from 
 **   http://www.codeproject.com/Tips/109443/Fibonacci-Recursive-and-Non-Recursive-C
 ** Description: Calculates a given Fibonacci number using iteration
 ** Parameters: Int representing number to find Fibonacci number of 
 ** Pre-Conditions: num must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
unsigned long IterativeFib::Fib(int num) {
  /*
   * Initialize unsigned longs first and second to values 0 and 1 in the
   * Fibonacci sequence
   */
  unsigned long first = 0;
  unsigned long second = 1;
  /*Initialize counter to 2 since first and second have been done*/
  int counter = 2;

  /*Continue until counter reaches num*/
  while(counter < num) {
    /*Create unsigned long temp and assign second*/
    unsigned long temp = second;
    /*Add first to second (making the next value)*/
    second = first + second;
    /*Assign most recent value to first*/
    first = temp;
    /*Increment counter*/
    counter++;
  }

  /*Base case*/
  if(num == 0) {
    return 0;
  }
  /*Recursive case adds last two values together*/
  else {
    return first + second;
  }
}

/**********************************************************************
 ** Function: printFib()
 ** Source: Modified from 
 **   http://www.codeproject.com/Tips/109443/Fibonacci-Recursive-and-Non-Recursive-C
 ** Description: Calls Fib() and prints result
 ** Parameters: None
 ** Pre-Conditions: n must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
void IterativeFib::printFib() {
  /*Call Fib() on n and assign to result*/   
  unsigned long result = Fib(n);

  /*Print result*/   
  cout << "\nNumber " << n << " in the Fibonacci sequence is " << result << "." << endl;
}


/**********************************************************************
 ** Program Filename: Factorial.hpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Declaration of the Factorial class, which will
 **   calculate the n! using single recursion and tail recursion
 ** Input: None
 ** Output: None
 *********************************************************************/

#ifndef FACTORIAL_HPP
#define FACTORIAL_HPP

#include <iostream>
using namespace std;

/*
 * Creation of Factorial class
 * See Factorial.cpp for full descriptions of functions and data members.
 */
class Factorial {
  private:
    unsigned long n;

  public:
    unsigned long rFact(int);
    unsigned long factHelper(int, int);
    unsigned long factorial(int);
};

#endif

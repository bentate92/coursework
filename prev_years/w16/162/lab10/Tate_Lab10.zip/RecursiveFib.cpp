
/**********************************************************************
 ** Program Filename: RecursiveFib.cpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Implementation of the RecursiveFib class, described in
 **   RecursiveFib.hpp
 ** Input: Responses to prompts
 ** Output: Various prompts
 *********************************************************************/

#include "RecursiveFib.hpp"
using namespace std;

/**********************************************************************
 ** Function: Constructor -- RecursiveFib()
 ** Description: Assigns num to n and calls printFib()
 ** Parameters: Int representing place in the Fibonacci sequence to find 
 **   the value of 
 ** Pre-Conditions: num must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
RecursiveFib::RecursiveFib(int num) {
  n = num;
  printFib();
}

/**********************************************************************
 ** Function: Fib()
 ** Source: Modified from 
 **   http://www.codeproject.com/Tips/109443/Fibonacci-Recursive-and-Non-Recursive-C
 ** Description: Calculates a given Fibonacci number using double
 **   recursion
 ** Parameters: Int representing number to find Fibonacci number of 
 ** Pre-Conditions: num must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
unsigned long RecursiveFib::Fib(int num) {
  /*Base cases*/
  if(num == 0) {
    return 0;
  }
  else if(num == 1) {
    return 1;
  }
  /*Double recursive case adds last two values together*/
  return Fib(num - 1) + Fib(num - 2);
}

/**********************************************************************
 ** Function: printFib()
 ** Source: Modified from 
 **   http://www.codeproject.com/Tips/109443/Fibonacci-Recursive-and-Non-Recursive-C
 ** Description: Calls Fib() and prints result
 ** Parameters: None
 ** Pre-Conditions: n must contain a value whose Fibonacci counterpart
 **   can fit in an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
void RecursiveFib::printFib() {
  /*Call Fib() on n and assign to result*/
  unsigned long result = Fib(n);

  /*Print result*/
  cout << "\nNumber " << n << " in the Fibonacci sequence is " << result << "." << endl;
}


/**********************************************************************
 ** Program Filename: Factorial.cpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Implementation of the Factorial class, described in
 **   Factorial.hpp
 ** Input: Responses to prompts
 ** Output: Various prompts
 *********************************************************************/

#include "Factorial.hpp"
using namespace std;

/**********************************************************************
 ** Function: rFact()
 ** Source: Lecture slides
 ** Description: Calculates a given factorial using single recursion
 ** Parameters: Int representing number to find factorial of 
 ** Pre-Conditions: num must contain a value whose factorial can fit in
 **   an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
unsigned long Factorial::rFact(int num) {
  /*Base case*/
  if(num == 1) {
    return 1;
  }
  /*Recursive case*/
  else {
    return num * rFact(num - 1);
  }
}

/**********************************************************************
 ** Function: factHelper()
 ** Source: Lecture slides
 ** Description: Calculates a given factorial using tail recursion
 ** Parameters: Int representing number to find factorial of, int 
 **   representing the result of the multiplication 
 ** Pre-Conditions: num must contain a value whose factorial can fit in
 **   an unsigned long int variable, result must start as 1
 ** Post-Conditions: None
 *********************************************************************/
unsigned long Factorial::factHelper(int num, int result) {
  /*Base case*/
  if(num == 1) {
    return result;
  }
  /*Recursive case*/
  else {
    return factHelper(num - 1, num * result);
  }
}

/**********************************************************************
 ** Function: factorial()
 ** Source: Lecture slides
 ** Description: Calls factHelper() with appropriate starting value of
 **   result
 ** Parameters: Int representing number to find factorial of
 ** Pre-Conditions: num must contain a value whose factorial can fit in
 **   an unsigned long int variable
 ** Post-Conditions: None
 *********************************************************************/
unsigned long Factorial::factorial(int num) {
  return factHelper(num, 1);
}

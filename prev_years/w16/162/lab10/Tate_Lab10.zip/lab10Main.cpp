
/**********************************************************************
 ** Program Filename: lab10Main.cpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Main function to provide prompts, and manage objects,
 **   and diff() function to calculate execution time for each method
 ** Input: Responses to prompts
 ** Output: Prompts for integers, calculated execution time
 *********************************************************************/

#include "IterativeFib.hpp"
#include "RecursiveFib.hpp"
#include "Factorial.hpp"
#include <time.h>
using namespace std;

/*Prototype for diff() function, described below*/
int diff(timespec ts1, timespec ts2);

/*Main function*/
int main() {
  /*Declare n to hold user-generated ints*/
  int n;
  /*Declare start and end timespecs for diff()*/
  timespec start;
  timespec end;

  /*Print Fibonacci start message*/
  cout << "Let's start by testing the iterative vs. recursive calculations of Fibonacci numbers." << endl;
  /*Continue until user enters quit value of -1*/
  while( n != -1) {
    /*Prompt user for integer and store in n*/
    cout << "\nPlease enter an integer from 0 to 93, or enter -1 to quit." << endl;
    cin >> n;
 
    /*Only run if user did not want to quit*/
    if(n != -1) {   
      /*Print iterative method beginning*/
      cout << "\nLet's try the iterative method..." << endl;
      
      /*Initialize start to current time*/
      clock_gettime(CLOCK_REALTIME, &start);
      /*Initialize IterativeFib object with n*/
      IterativeFib IFib(n);
      /*Initialize end to current time*/
      clock_gettime(CLOCK_REALTIME, &end);
      /*Call diff() and print execution time*/
      cout << "The calculation took " << diff(start, end) << " nanoseconds." << endl;
    
      /*Print recursive method beginning*/
      cout << "\nNow let's try the recursive method..." << endl;
  
      /*Initialize start to current time*/
      clock_gettime(CLOCK_REALTIME, &start);
      /*Initialize RecursiveFib object with n*/
      RecursiveFib RFib(n);
      /*Initialize end to current time*/  
      clock_gettime(CLOCK_REALTIME, &end);
      /*Call diff() and print execution time*/   
      cout << "The calculation took " << diff(start, end) << " nanoseconds." << endl;
    }
  }  

  /*Assign 0 to n so that next loop will run*/
  n = 0;

  /*Print factorial start message*/
  cout << "\nNow let's test standard recursive vs. tail-recursive factorial calculations." << endl;
  /*Continue until user enters quit value of -1*/     
  while(n != -1) {
    /*Prompt user for integer and store in n*/  
    cout << "\nPlease enter an integer from 1 to 12, or enter -1 to quit." << endl;
    cin >> n;
    
    /*Only run if user did not want to quit*/
    if(n != -1) {
      /*Declare Factorial object*/
      Factorial fact;
  
      /*Print single recursive method beginning*/        
      cout << "\nLet's try the single recursive method..." << endl;
  
      /*Initialize start to current time*/        
      clock_gettime(CLOCK_REALTIME, &start);
      /*Call rFact() on n and print result*/   
      cout << "\nThe factorial is " << fact.rFact(n) << "." << endl; 
      /*Initialize end to current time*/
      clock_gettime(CLOCK_REALTIME, &end);
      /*Call diff() and print execution time*/ 
      cout << "The calculation took " << diff(start, end) << " nanoseconds." << endl;
  
      /*Print single recursive method beginning*/  
      cout << "\nNow let's try the tail-recursive method..." << endl;
      
      /*Initialize start to current time*/   
      clock_gettime(CLOCK_REALTIME, &start);
      /*Call factorial() on n and print result*/
      cout << "\nThe factorial is " << fact.factorial(n) << "." << endl;
      /*Initialize end to current time*/   
      clock_gettime(CLOCK_REALTIME, &end);
      /*Call diff() and print execution time*/  
      cout << "The calculation took " << diff(start, end) << " nanoseconds." << endl;
    }
  }

  return 0;
}

/**********************************************************************
 ** Function: diff()
 ** Source: Modified from 
 **   https://www.guyrutenberg.com/2007/09/22/profiling-code-using-clock_gettime/
 ** Description: Calculates difference in nanoseconds between two 
 **   timespecs
 ** Parameters: Two timespecs, representing the start and end of the
 **   function execution
 ** Pre-Conditions: ts1 and ts2 must be initialized at appropriate times
 ** Post-Conditions: None
 *********************************************************************/
int diff(timespec ts1, timespec ts2) {
  /*Create diff timespec*/
  timespec diff;
  
  /*Calculate difference in times of ts1 and ts2 and assign to diff*/
  diff.tv_nsec = ts2.tv_nsec - ts1.tv_nsec;

  /*Return diff in nanoseconds*/
  return diff.tv_nsec;
}


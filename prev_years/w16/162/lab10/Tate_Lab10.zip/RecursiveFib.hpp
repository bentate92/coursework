
/**********************************************************************
 ** Program Filename: RecursiveFib.hpp
 ** Author: Benjamin Tate
 ** Date: 3/11/16
 ** Description: Declaration of the RecursiveFib class, which will
 **   use double recursion to calculate a given number in the Fibonacci
 **   sequence
 ** Input: None
 ** Output: None
 *********************************************************************/

#ifndef RECURSIVEFIB_HPP
#define RECURSIVEFIB_HPP

#include <iostream>
using namespace std;

/*
 * Creation of RecursiveFib class
 * See RecursiveFib.cpp for full descriptions of functions and data members.
 */
class RecursiveFib {
  private:
    int n;

  public:
    RecursiveFib(int);
    unsigned long Fib(int);
    void printFib();
};

#endif

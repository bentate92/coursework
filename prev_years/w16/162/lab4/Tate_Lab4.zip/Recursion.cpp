
/**********************************************************************
 ** Program Filename: Recursion.cpp
 ** Author: Benjamin Tate
 ** Date: 1/31/16
 ** Description: Provides user with choice of three different functions 
 ** Input: Various prompted values
 ** Output: Various prompts
 *********************************************************************/

#include <iostream>
#include <string>

using namespace std;

/*
 * Prototype of reverseString() function
 * (See below for details)
 */
string reverseString(string);

/*
 * Prototype of arraySum() function
 * (See below for details)
 */
int arraySum(int[], int);

/*
 * Prototype of tri() function
 * (See below for details)
 */
int tri(int);

/**********************************************************************
 ** Function: main()
 ** Description: Provides user with choice of functions to run, prompts
 **   for necessary values, makes necessary function calls, and then
 **   prints the results
 ** Parameters: None
 ** Pre-Conditions: None 
 ** Post-Conditions: None
 *********************************************************************/
int main() {
  /*Initialize string to hold function selection*/
  string choice;

  /*Prompt user for choice of function and store response in choice*/
  cout << "What would you like me to do for you?" << endl;
  cout << "a = Reverse a string" << endl;
  cout << "b = Sum some integers" << endl;
  cout << "c = Find a triangle number" << endl;
  cout << "Anything else = Quit" << endl;  
  cin >> choice;

  /*Run reverseString() function*/
  if(choice == "a") { 
    /*Initialize string to be reversed*/
    string userStr;
    
    /*Prompt user for the string they want reversed, store in userStr*/
    cout << "\nPlease type a string for me to reverse:" << endl;
    cin >> userStr;
  
    /*Call reverseString and print result*/
    cout << "\nHere is the string in reverse:" << endl;
    cout << reverseString(userStr) << "\n" << endl;
  } 
  /*Run arraySum() function*/
  else if(choice == "b") {
    /*Initialize int for array length*/
    int arrLen;
    
    /*Prompt user for array length and store in arrLen*/
    cout << "\nAlright, I'll sum some numbers for you." <<
            " How many integers would you like to enter?" << endl;
    cin >> arrLen;
  
    /*Initialize array of appropriate length*/
    int array[arrLen];
    
    /*Prompt user for appropriate number of integers*/
    cout << "\nOkay, please enter " << arrLen << " integers:" << endl;
    
    /*Store integers in array*/
    for(int i = 0; i < arrLen; i++) {
      cin >> array[i];
    }
  
    /*Call arraySum() and print result*/
    cout << "\nThe sum of those integers is " <<
            arraySum(array, arrLen) << ".\n" << endl;
  } 
  /*Run tri() function*/
  else if(choice == "c") {  
    /*Initialize int to find the triangle number for*/
    int N;
  
    /*Prompt user for N*/
    cout << "\nOkay, please enter an integer for which you " <<
            "would like me to find the triangle number:" << endl;
    cin >> N;
  
    /*Call tri() and print result*/
    cout << "\nThe triangle number for " << N << " is " <<
            tri(N) << ".\n" << endl;
  } 
  /*If user does not select a, b, or c, exit*/
  else {
    cout << "\nOkay, exiting now.\n" << endl;
  }
  return 0;
}

/**********************************************************************
 ** Function: reverseString()
 ** Description: Reverses a string passed to it
 ** Parameters: A string to be reversed
 ** Pre-Conditions: userStr must exist and be passed into the function
 ** Post-Conditions: None
 *********************************************************************/
string reverseString(string userStr) {
    /*Base case to stop recursion*/
    if(userStr.length() == 0) {
      return "";  
    }
  
    /*Create string to hold last character of userStr*/
    string lastChar(1,userStr[userStr.length() - 1]);
  
    /*Use substr() to recursively reverse the rest of the string*/
    string restReverse = 
           reverseString(userStr.substr(0, userStr.length() - 1));
  
    /*Create combine lastChar and restReverse into finalStr and return*/
    string finalStr = lastChar + restReverse;
  
    return finalStr;
}

/**********************************************************************
 ** Function: arraySum()
 ** Description: Determines the sum of the integers in the array passed
 ** Parameters: An array of ints and an int representing the length of
 **   that array
 ** Pre-Conditions: arr[] and len must exist and have values
 ** Post-Conditions: None
 *********************************************************************/
int arraySum(int arr[], int len) {
  /*Base case to stop recursion when len reaches 0*/
  if(len <= 0) {
    return 0;
  }
  /*On each recursion, add the next element of arr and decrease len*/
  else {
    return arr[0] + arraySum(arr + 1, len - 1);
  }
}  

/**********************************************************************
 ** Function: tri()
 ** Description: Finds the triangle number of an integer passed to it
 ** Parameters: An int to find the triangle number for
 ** Pre-Conditions: n must exist and have a value
 ** Post-Conditions: None
 *********************************************************************/
int tri(int n) {
  /*Base Case to stop recursion when n reaches 0*/
  if(n < 1) {
    return 0;
  }

  /*On each recursion, add current integer to the next integer below*/
  return n + tri(n - 1);
}







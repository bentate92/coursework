/*********************************************************************
 ** Program Filename: determinant.hpp
 ** Author: Benjamin Tate
 ** Date: 1/10/16
 ** Description: Prototype of determinant() function
 ** Input: none
 ** Output: none
 *********************************************************************/

int determinant(int a[3][3], int size);



/*********************************************************************
 ** Program Filename: readMatrix.hpp
 ** Author: Benjamin Tate
 ** Date: 1/10/16
 ** Description: Prototype of readMatrix() function
 ** Input: none
 ** Output: none
 *********************************************************************/

void readMatrix(int (*a)[3][3], int size);



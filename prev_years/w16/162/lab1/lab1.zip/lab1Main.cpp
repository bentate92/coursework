/*********************************************************************
 ** Program Filename: lab1Main.cpp
 ** Author: Benjamin Tate
 ** Date: 1/10/16
 ** Description: Main function to prompt user for the size of matrix
 **   they want to create, call readMatrix() and determinant() to 
 **   populate the matrix and find the determinant, respectively, and 
 **   print the array and determinant.
 ** Input: Array size (4 or 9)
 ** Output: Prompts for user, array, determinant
 *********************************************************************/

#include <iomanip>
#include <iostream>
#include "readMatrix.hpp"
#include "determinant.hpp"

using namespace std;

/*********************************************************************
 ** Function: main()
 ** Description: Prompts user for matrix size, calls readMatrix() and
 **   determinant(), and prints the matrix and determinant.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/
int main() {
  int area;
  int determ;
  int array[3][3];
  int (*p_array)[3][3] = &array;

  /* Prompt user for matrix size */
  cout << "We are going to make a square array and find the determinant!"
  "\nPlease enter either '4' or '9' to choose the size of the array:" 
  << endl;
  /* Assign user input to int variable area */
  cin >> area;
  /* Tell the user the what will happen when readMatrix() is called */
  if(area == 4) {
    cout << "\nOkay, let's populate our 2x2 array, cell by cell, and then"
  " I'll calculate the determinant." << endl;
  }
  else if(area == 9) {
    cout << "\nOkay, let's populate our 3x3 array, cell by cell, and then"
  " I'll calculate the determinant." << endl;
  }
  
  readMatrix(p_array, area);

  determ = determinant(array, area);

  /* Print matrix in a stylish table */
  cout << "\nHere's the array:" << endl;
  if(area == 4) {
    cout << "|-----|-----|" << endl;
    cout << "|" << setw(5) << array[0][0] << "|" << setw(5) << 
    array [0][1] << "|" << endl;
    cout << "|-----|-----|" << endl;
    cout << "|" << setw(5) << array[1][0] << "|" << setw(5) << 
    array [1][1] << "|" << endl;
    cout << "|-----|-----|" << endl;
  }
  else if(area == 9) {
    cout << "|-----|-----|-----|" << endl;
    cout << "|" << setw(5) << array[0][0] << "|" << setw(5) << 
    array[0][1] << "|" << setw(5) << array[0][2] << "|" << endl;
    cout << "|-----|-----|-----|" << endl;
    cout << "|" << setw(5) << array[1][0] << "|" << setw(5) << 
    array[1][1] << "|" << setw(5) << array[1][2] << "|" << endl;
    cout << "|-----|-----|-----|" << endl;
    cout << "|" << setw(5) << array[2][0] << "|" << setw(5) << 
    array[2][1] << "|" << setw(5) << array[2][2] << "|" << endl;
    cout << "|-----|-----|-----|" << endl;
  }

  /* Print determinant */
  cout << "\nAnd the determinant for the array is " << determ << "." << endl;

  return 0;
}

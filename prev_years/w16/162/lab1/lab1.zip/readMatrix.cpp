/*********************************************************************
 ** Program Filename: readMatrix.cpp
 ** Author: Benjamin Tate
 ** Date: 1/10/16
 ** Description: Description of readMatrix() function
 ** Input: Integers to populate a 2D array
 ** Output: Prompts for 2D array population
 *********************************************************************/

#include <iostream>
#include "readMatrix.hpp"

using namespace std;

/*********************************************************************
 ** Function: readMatrix()
 ** Description: Prompts user to fill a matrix of the given size
 ** Parameters: Pointer to 2D array of ints, int for area of the
 **   square matrix
 ** Pre-Conditions: 2D array of ints must exist, matrix area must be
 **   chosen (either 4 or 9)
 ** Post-Conditions: 2D array must be populated with 4 or 9 values in
 **   the proper cells
 *********************************************************************/
void readMatrix(int (*a)[3][3], int size) {
  /* To be executed if the matrix is to be 2x2 */
  if(size == 4) {
    /* For rows 1 and 2 */
    for(int i = 0; i < 2; i++) {
      /* For columns 1 and 2 */
      for(int j = 0; j < 2; j++) {
        /*Prompt user for current cell value */
        cout << "Row " << i + 1 << ", Column " << j + 1 << ":" << endl;
        /* Populate array at current cell with user input */
        cin >> (*a)[i][j];
      }
    }
  }

  /* To be executed if the matrix is to be 3x3 */
  else if(size == 9) {
    /* For rows 1-3 */
    for(int i = 0; i < 3; i++) {
      /* For columns 1-3 */
      for(int j = 0; j < 3; j++) {
        /*Prompt user for current cell value */
        cout << "Row " << i + 1 << ", Column " << j + 1 << ":" << endl;
        /* Populate array at current cell with user input */
        cin >> (*a)[i][j];
      }
    }
  }
}

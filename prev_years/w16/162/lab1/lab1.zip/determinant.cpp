/*********************************************************************
 ** Program Filename: determinant.cpp
 ** Author: Benjamin Tate
 ** Date: 1/10/16
 ** Description: Description of determinant() function
 ** Input: A 2D array of integers, representing a 2x2 or 3x3 matrix
 ** Output: The integer determinant of the matrix
 *********************************************************************/

#include "determinant.hpp"

/*********************************************************************
 ** Function: determinant()
 ** Description: Given a square matrix of area 4 or 9, finds the 
 **   determinant of the matrix
 ** Parameters: 2D array of ints, int for area of the square matrix
 ** Pre-Conditions: 2D array of ints must exist, matrix area must be
 **   chosen (either 4 or 9)
 ** Post-Conditions: None
 *********************************************************************/
int determinant(int a[3][3], int size) {
  int determinant;

  /* Formula for the determinant of a 2x2 matrix */
  if(size == 4) {
    determinant = (a[0][0] * a[1][1]) - (a[0][1] * a[1][0]);
  }

  /* Formula for the determinant of a 3x3 matrix */
  else if(size == 9) {
    determinant = (a[0][0] * ((a[1][1] * a[2][2]) - (a[1][2] * a[2][1]))) - 
                  (a[0][1] * ((a[1][0] * a[2][2]) - (a[1][2] * a[2][0]))) +
                  (a[0][2] * ((a[1][0] * a[2][1]) - (a[1][1] * a[2][0])));
  }

  return determinant;
}


/**********************************************************************
 ** Program Filename: finalMain.cpp
 ** Author: Benjamin Tate
 ** Date: 3/15/16
 ** Description: Main function to create Character
 ** Input: None
 ** Output: None
 *********************************************************************/

#include "Character.hpp"
using namespace std;

int main() {
  /*Create Character object*/
  Character c;

  return 0;
}

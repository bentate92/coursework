
/*********************************************************************
 ** Program Filename: lab3Main.cpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Main method to run and provide user interface for the
 ** game
 ** Input: Various responses to prompts
 ** Output: Prompts and results for the game
 *********************************************************************/

#include <iostream>
#include <string>
#include "Game.hpp"

using namespace std;

int main() {
  /*Initialize int to hold user-selected # of sides for P1*/
  int p1sides;
  /*Initialize string to hold user choice for loaded/regular for P1*/
  string p1choice;
  /*Initialize bool representing whether P1's die is loaded to false*/
  bool p1load = false;

  /*Initialize int to hold user-selected # of sides for P2*/
  int p2sides;
  /*Initialize string to hold user choice for loaded/regular for P2*/
  string p2choice;
  /*Initialize bool representing whether P2's die is loaded to false*/
  bool p2load = false;

  /*Initialize int to hold user-selected number of rounds*/
  int roundCount;

  /*Start off and prompt user for # of sides for the first die*/
  cout << "Let's play dice!\n" << endl;
  cout << "To start off, how many sides will the first player's die have?" 
  << endl;
  /*Store number of sides for first die in p1sides*/
  cin >> p1sides;

  /*Prompt user to indicate wheter first die will be loaded*/
  cout << "\nAnd would you like the first player's die to be loaded? (y/n)" 
  << endl;
  /*Store user response in p1choice*/
  cin >> p1choice;

  /*If user indicated that the die should be loaded, set p1load to true*/
  if(p1choice == "y") {
    p1load = true;
  }

  /*Prompt user for # of sides for the second die*/
  cout << "\nNow, how many sides will the second player's die have?" << endl;
  /*Store number of sides for second die in p2sides*/
  cin >> p2sides;

  /*Prompt user to indicate wheter second die will be loaded*/
  cout << "\nAnd would you like the second player's die to be loaded? (y/n)" 
  << endl;
  /*Store user response in p2choice*/
  cin >> p2choice;

  /*If user indicated that the die should be loaded, set p2load to true*/
  if(p2choice == "y") {
    p2load = true;
  }

  /*Prompt user for number of rounds*/
  cout << "\nLastly, how many rounds would you like to play?" << endl;
  /*Store response in roundCount*/
  cin >> roundCount;

  /*Estimate simulation time so that user knows it is running*/
  cout << "\nPlease wait --  The simulation should take about " 
  << roundCount * 2 << " seconds." << endl;

  /*Creat Game object using user-selected values*/
  Game game(p1sides, p1load, p2sides, p2load, roundCount);

  /*Once the game is complete, print final scores*/
  cout << "\nAfter " << roundCount << " rounds, the final score is:" << endl;
  cout << "Player 1: " << game.getScore1() << endl;
  cout << "Player 2: " << game.getScore2() << endl;

  /*Compare scores and print winner*/
  if(game.getScore1() > game.getScore2()) {
    cout << "Player 1 wins!" << endl;
  }
  else if(game.getScore1() < game.getScore2()) {
    cout << "Player 2 wins!" << endl;
  }
  else {
    cout << "It's a draw!" << endl;
  }
  
  return 0;
}




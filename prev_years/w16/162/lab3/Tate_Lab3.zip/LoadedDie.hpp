
/*********************************************************************
 ** Program Filename: LoadedDie.hpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Declaration of the LoadedDie class
 ** Input: none
 ** Output: none
 *********************************************************************/

#ifndef LOADEDDIE_HPP
#define LOADEDDIE_HPP

#include "Die.hpp"

/* 
 * Creation of LoadedDie class (which is a sublcass of Die)
 * See LoadedDie.cpp for full descriptions of functions and data members
 */
class LoadedDie : public Die {
  private:

  public:
    LoadedDie();
    LoadedDie(int sideCount);
    void roll();
};

#endif

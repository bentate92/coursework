
/*********************************************************************
 ** Program Filename: Game.cpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Implementation of the Game class described in Game.hpp
 ** Input: Two integers, representing the number of sides for each
 ** player's die, two booleans, representing whether or not each 
 ** player's die it loaded, and one integer, representing the number of
 ** rounds to run the game for
 ** Output: Scores for each player
 *********************************************************************/

#include "Game.hpp"

/*********************************************************************
 ** Function: Constructor -- Game()
 ** Description: Sets sides1, isLoaded1, sides2, isLoaded2, and rounds
 ** to the values of their respective parameters, initializes each
 ** player's score to zero, creates Die and LoadedDie objects for each
 ** player, runs setScore() once for each round
 ** Parameters: Two integers, representing the number of sides for each
 ** player's die, two booleans, representing whether or not each 
 ** player's die it loaded, and one integer, representing the number of
 ** rounds to run the game for 
 ** Pre-Conditions: Parameters must exist, integer parameters, must be
 ** at least 1
 ** Post-Conditions: None
 *********************************************************************/
Game::Game(int p1sides, bool p1load, int p2sides, bool p2load, 
           int roundCount) {
  /*Set sides1&2 and isLoaded1&2 to respective parameter values*/
  sides1 = p1sides;
  isLoaded1 = p1load;
  sides2 = p2sides;
  isLoaded2 = p2load;
 
  /*Set rounds to respective parameter value*/
  rounds = roundCount;

  /*Initialize score1 and score2 to zero*/
  score1 = 0;
  score2 = 0;

  /*Create Die and LoadedDie objects for each player*/
  Die die1(sides1);
  Die die2(sides2);
  LoadedDie loadDie1(sides1);
  LoadedDie loadDie2(sides2);

  /*Run setScore() for the number of rounds*/
  for(int i = 0; i < rounds; i++) {
    setScore(die1, die2, loadDie1, loadDie2);
  }
}

/*********************************************************************
 ** Function: setScore()
 ** Description: Chooses Die or LoadedDie objects for each player and
 ** rolls each, and then updates the scores according to who won
 ** Parameters: Two Die objects and two LoadedDie objects
 ** Pre-Conditions: Die and LoadedDie objects must exist
 ** Post-Conditions: None
 *********************************************************************/
void Game::setScore(Die firstDie, Die secondDie, 
                    LoadedDie firstLoad, LoadedDie secondLoad) {
  /*If P1's die is loaded, use roll() with LoadedDie object*/
  if(isLoaded1 == true) {
    firstLoad.roll();
  }
  /*If P1's die isn't loaded, use roll() with Die object*/
  else {
    firstDie.roll();
  }

  /*Pause for 1 second to ensure that next roll is not identical*/
  sleep(1);

  /*If P2's die is loaded, use roll() with LoadedDie object*/
  if(isLoaded2 == true) {
    secondLoad.roll();
  }
  /*If P2's die isn't loaded, use roll() with Die object*/
  else {
    secondDie.roll();
  }

  /*Pause for 1 second to ensure that next roll is not identical*/
  sleep(1);

  /*
   * Determine combination of loaded/regular die and compare rolls to
   * determine the round's winner; update score of winner
   */
  if(isLoaded1 == true && isLoaded2 == true) {
    if(firstLoad.getRoll() > secondLoad.getRoll()) {
      score1++;
    }
    else if(firstLoad.getRoll() < secondLoad.getRoll()) {
      score2++;
    }
  }
  else if(isLoaded1 == true && isLoaded2 == false) {
    if(firstLoad.getRoll() > secondDie.getRoll()) {
      score1++;
    }
    else if(firstLoad.getRoll() < secondDie.getRoll()) {
      score2++;
    }
  }
  else if(isLoaded1 == false && isLoaded2 == true) {
    if(firstDie.getRoll() > secondLoad.getRoll()) {
      score1++;
    }
    else if(firstDie.getRoll() < secondLoad.getRoll()) {
      score2++;
    }
  }
  else if(isLoaded1 == false && isLoaded2 == false) {
    if(firstDie.getRoll() > secondDie.getRoll()) {
      score1++;
    }
    else if(firstDie.getRoll() < secondDie.getRoll()) {
      score2++;
    }
  }
}

/*********************************************************************
 ** Function: getScore1()
 ** Description: Returns first player's score
 ** Parameters: None
 ** Pre-Conditions: score1 must contain an integer
 ** Post-Conditions: None
 *********************************************************************/
int Game::getScore1() {
  return score1;
}

/*********************************************************************
 ** Function: getScore2()
 ** Description: Returns second player's score
 ** Parameters: None
 ** Pre-Conditions: score2 must contain an integer
 ** Post-Conditions: None
 *********************************************************************/
int Game::getScore2() {
  return score2;
}



/*********************************************************************
 ** Program Filename: Die.cpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Implementation of the Die class described in Die.hpp
 ** Input: Integer representing number of sides
 ** Output: rollVal integer, which represents the latest roll
 *********************************************************************/

#include "Die.hpp"

/*********************************************************************
 ** Function: Default constructor -- Die()
 ** Description: Sets sides int to zero
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/
Die::Die() {
  sides = 0;
}

/*********************************************************************
 ** Function: Constructor -- Die()
 ** Description: Sets sides int to value of int parameter
 ** Parameters: Integer representing number of sides
 ** Pre-Conditions: Integer parameter must exist
 ** Post-Conditions: None
 *********************************************************************/
Die::Die(int sideCount) {
  sides = sideCount;
}

/*********************************************************************
 ** Function: roll()
 ** Description: Sets rollVal to a random value between 1 and sides
 ** Parameters: None
 ** Pre-Conditions: Integer sides must be >= 1
 ** Post-Conditions: None
 *********************************************************************/
void Die::roll() {
  /*seed is set according to current time*/
  unsigned seed = time(0);
  /*rand() algorithm is set to start with seed*/
  srand(seed);

  /*rollVal is set using rand() algorithm between 1 and sides*/
  rollVal = rand() % sides + 1;
}

/*********************************************************************
 ** Function: getRoll()
 ** Description: Returns rollVal
 ** Parameters: None
 ** Pre-Conditions: rollVal must contain an integer
 ** Post-Conditions: None
 *********************************************************************/
int Die::getRoll() {
  return rollVal;
}

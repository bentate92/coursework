
/*********************************************************************
 ** Program Filename: Die.hpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Declaration of the Die class
 ** Input: none
 ** Output: none
 *********************************************************************/

#ifndef DIE_HPP
#define DIE_HPP

#include <cstdlib>
#include <time.h>
#include <unistd.h>

/* 
 * Creation of Die class
 * See Die.cpp for full descriptions of functions and data members.
 */
class Die {
  private:

  protected:
    int sides;
    int rollVal;

  public:
    Die();
    Die(int sideCount);
    void roll();
    int getRoll();
};

#endif

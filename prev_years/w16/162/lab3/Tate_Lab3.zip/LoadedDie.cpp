
/*********************************************************************
 ** Program Filename: LoadedDie.cpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Implementation of the LoadedDie class described in 
 ** Die.hpp
 ** Input: Integer representing number of sides
 ** Output: rollVal integer, which represents the latest roll
 *********************************************************************/

#include "LoadedDie.hpp"

/*********************************************************************
 ** Function: Default constructor -- LoadedDie()
 ** Description: Sets sides int to zero
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/
LoadedDie::LoadedDie() : Die() {
  sides = 0;
}

/*********************************************************************
 ** Function: Constructor -- LoadedDie()
 ** Description: Sets sides int to value of int parameter
 ** Parameters: Integer representing number of sides
 ** Pre-Conditions: Integer parameter must exist
 ** Post-Conditions: None
 *********************************************************************/
LoadedDie::LoadedDie(int sideCount) {
  sides = sideCount;
}

/*********************************************************************
 ** Function: roll()
 ** Description: Sets rollVal to a random value between sides/2
 ** (rounding up)  and sides
 ** Parameters: None
 ** Pre-Conditions: Integer sides must be >= 1
 ** Post-Conditions: None
 *********************************************************************/
void LoadedDie::roll() {
  unsigned seed = time(0);
  srand(seed);
  
  if(sides % 2 == 0) {
    rollVal = rand() % (sides / 2) + ((sides / 2) + 1);
  }
  else {
    rollVal = rand() % (sides / 2) + ((sides / 2) + 2);
  }
}

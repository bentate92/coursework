
/*********************************************************************
 ** Program Filename: Game.hpp
 ** Author: Benjamin Tate
 ** Date: 1/24/16
 ** Description: Declaration of the Game class
 ** Input: none
 ** Output: none
 *********************************************************************/

#ifndef GAME_HPP
#define GAME_HPP

#include "LoadedDie.hpp"

/* 
 * Creation of Game class
 * See Game.cpp for full descriptions of functions and data members.
 */
class Game {
  private:
    int sides1;
    bool isLoaded1;
    int sides2;
    bool isLoaded2;

    int rounds;
 
    int score1;
    int score2;

  public:
    Game(int p1sides, bool p1load, int p2sides, bool p2load, int roundCount);
    void setScore(Die firstDie, Die secondDie, LoadedDie firstLoad, LoadedDie secondLoad);
    int getScore1();
    int getScore2();
};

#endif

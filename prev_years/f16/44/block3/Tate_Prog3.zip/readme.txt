+--------------------------------------------------------------------------------+
| Name: Benjamin Tate															 |
| Date: 11/17/2016																 |
| Class: CS 344																	 |
| Assignment: Program 3															 |
| Description: Instructions for compiling, running and testing smallsh			 |
+--------------------------------------------------------------------------------+

Compiling:
	To compile the program using the included Makefile, type 'make compile'.
	Otherwise, to manually compile, use 'gcc -o smallsh smallsh.c'.

Running:
	To run the program, use './smallsh' or 'make run'. Using 'make comp_run' will
	complile the program and run it immediately.

Testing:
	If a copy of p3testscript is in the same directory as smallsh and the Makefile,
	'make test' can be used as a shortcut for './p3testscript > mytestresults 2>&1',
	and 'make comp_test' will compile the program and run the same test immediately.

Cleaning:
	Use 'make clean' if you want to remove files created from compiling and running
	smallsh in the current directory. To also remove test directories created by the 
	test in the home dir, 'make superclean' can be used.
	***WARNING*** superclean will remove all files in the home directory whose names
	begin with 'testdir', not only ones created from testing this specific program.

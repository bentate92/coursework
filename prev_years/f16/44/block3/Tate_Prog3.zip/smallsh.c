/*****************************************************************************************
* Name: Benjamin Tate
* Date: 11/17/2016
* Class: CS 344
* Assignment: Program 3
* Description: Implementation of a simple shell that includes 3 basic commands (status, cd,
*	and exit), and defers to bash for others
******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>

int main() {
	//Initialize string to hold input
	char input[2049];
	//Initialize array of arguments
	char* args[513];

	//Initialize string to hold parsed command segments
	char* parse;

	//Initialize strings to hold input/output file names
	char* inFile = NULL;
	char* outFile = NULL;
	//Initialize input/output file descriptors
	int inFd = -1;
	int outFd = -1;

	//Boolian to distinguish foreground/background processes
	int foreground;

	//Int to hold status code
	int status = 0;

	//Int to hold pid
	int pid;

	//Boolean to tell when exit has been requested
	int quit = 0;

	//Create sigaction struct
	struct sigaction sig;
	//Create signal handler
	sig.sa_handler = SIG_IGN;
	//Initialize sigaction flags to 0
	sig.sa_flags = 0;
	//Set SIGINT handler
	sigaction(SIGINT, &sig, NULL);

	//Continue as long as exit has not been requested
	while(quit == 0) {
		//Default foreground to 1
		foreground = 1;

		//Print colon as prompt and flush stdout
		printf(": ");
		fflush(stdout);

		//Get input command
		if(fgets(input, 2049, stdin) == NULL) {
			return 0;
		}

		//Initialize int to hold number of arguments in array
		int argCount = 0;
		//Parse input and set input/output filenames
		parse = strtok(input, " \n");
		while(parse != NULL) {
			if(strcmp(parse, "<") == 0) {
				//Following string is input filename
				parse = strtok(NULL, " \n");
				inFile = strdup(parse);
				//Move to next section of input
				parse = strtok(NULL, " \n");
			} else if(strcmp(parse, ">") == 0) {
				//Following string is output filename
				parse = strtok(NULL, " \n");
				outFile = strdup(parse);
				//Move to next section of input
				parse = strtok(NULL, " \n");
			} else if(strcmp(parse, "&") == 0) {
				//Command to be run in background
				foreground = 0;
				break;
			} else {
				//Store command/argument in args array
				args[argCount] = strdup(parse);
				//Move to next section of input
				parse = strtok(NULL, " \n");
				//Increment argCount
				argCount++;
			}
		}

		//Set final element of argCount to NULL
		args[argCount] = NULL;

		if(args[0] == NULL || *(args[0]) == '#') {
			//There are no arguments, or if argument is a comment, so do nothing
		} else if(strcmp(args[0], "cd") == 0) {
			//Command is cd
			if(args[1] == NULL) {
				//No argument for cd, so go home
				chdir(getenv("HOME"));
			} else {
				//Go to specified directory
				chdir(args[1]);
			}
		} else if(strcmp(args[0], "status") == 0) {
			//Command is status
			if(WIFEXITED(status)) {
				//Print exit status
				printf("Exit status: %i\n", WEXITSTATUS(status));
			} else {
				//Print terminating signal of last foreground process
				printf("Last foreground process terminated by signal %i\n", status);
			}
		} else if(strcmp(args[0], "exit") == 0) {
			//Command is exit, exit and set quit to 1
			exit(0);
			quit = 1;
		} else {
			//Command is unrecognized

			//Create fork to execute command in
			pid = fork();
			//Test return of fork()
			switch(pid) {
				case 0: //In child process
					if(foreground == 1) {
						//Process is in foreground, so set signal handler to default
						sig.sa_handler = SIG_DFL;
						sig.sa_flags = 0;
						sigaction(SIGINT, &sig, NULL);
					}

					if(inFile != NULL) {
						//Input file exists, so open in read only mode
						inFd = open(inFile, O_RDONLY);
						//Check that file was successfully opened
						if(inFd == -1) {
							printf("ERROR: smallsh was unable to open %s for input\n", inFile);
							fflush(stdout);
							exit(1);
						}

						//Redirect input and check success
						if(dup2(inFd, 0) == -1) {
							fprintf(stderr, "ERROR: smallsh dup2 failed");
							exit(1);
						}

						//Close input file
						close(inFd);
					} else if(foreground == 0) {
						//Process is in background, so redirect to /dev/null
						inFd = open("/dev/null", O_RDONLY);
						//Check that /dev/null was opened successfully
						if(inFd == -1) {
							fprintf(stderr, "ERROR: smallsh could not open /dev/null");
							exit(1);
						}

						//Redirect input and check success
						if(dup2(inFd, 0) == -1) {
							fprintf(stderr, "ERROR: smallsh dup2 failed");
							exit(1);
						}

						//Close input file
						close(inFd);
					}

					if(outFile != NULL) {
						//Output file exists, so open file
						outFd = open(outFile, O_WRONLY | O_CREAT | O_TRUNC, 0755);
						//Check that file was successfully opened
						if(outFd == -1) {
							printf("ERROR: smallsh was unable to open %s for output\n", outFile);
							fflush(stdout);
							exit(1);
						}

						//Redirect output and check success
						if(dup2(outFd, 1) == -1) {
							fprintf(stderr, "ERROR: smallsh dup2 failed");
							exit(1);
						}

						//Close output file
						close(outFd);
					}

					//Execute commands stored in args and check success
					if(execvp(args[0], args)) {
						fprintf(stderr, "ERROR: the command \"%s\" is not recognized\n", args[0]);
						fflush(stdout);
						exit(1);
					}

					break;

				case -1: //Something went wrong with fork(), print error
					fprintf(stderr, "ERROR: smallsh fork error");
					status = 1;
					break;

				default: //In parent process
					if(foreground == 1) {
						//Wait for foreground process to finish
						waitpid(pid, &status, 0);
					} else {
						//Process is in background, print pid
						printf("Background pid: %i\n", pid);
						break;
					}
			}
		}

		//Free strings that will be used again
		int i;
		for(i = 0; args[i] != NULL; i++) {
			free(args[i]);
		}
		free(inFile);
		inFile = NULL;
		free(outFile);
		outFile = NULL;

		//Check for completed processes and print message
		pid = waitpid(-1, &status, WNOHANG);
		while(pid > 0) {
			printf("Background process #%i complete. ", pid);
			//Print status
			if(WIFEXITED(status)) {
				printf("Exit status: %i\n", WEXITSTATUS(status));
			} else {
				printf("Last foreground process terminated by signal %i\n", status);
			}

			pid = waitpid(-1, &status, WNOHANG);
		}
	}

	return 0;
}

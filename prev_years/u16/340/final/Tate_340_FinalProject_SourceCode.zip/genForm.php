<!--
  * Name: Benjamin Tate
  * Date: 8/7/2016
  * Assignment: CS340 - Final Project
  * Filename: genForm.php
  * Description: Web page to add to genres database and table
  * Project URL: http://web.engr.orst.edu/~tateb/webView.php?
-->

<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connect to onid database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","tateb-db","uTwrzZZIqCgNJ5Nh","tateb-db");
if($mysqli->connect_errno) {
	echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}

//Run query to insert new genre into genres table and spring errors if needed
if(!($stmt = $mysqli->prepare("INSERT INTO genres (genre) VALUES (?)"))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("s",$_POST['genName']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
    echo "Added " . $stmt->affected_rows . " rows to genres.";
}
?>

<br>
<!--Render back button-->
<form id='back' method='get' action='webView.php'>
    <input id='submit' type='submit' value='Back'>
</form>

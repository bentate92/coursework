<!--
  * Name: Benjamin Tate
  * Date: 8/7/2016
  * Assignment: CS340 - Final Project
  * Filename: webView.php
  * Description: Main page of final project website. Displays relevant tables, as well as forms 
  * 	to add entries to each table, and a form to search for details about an artist
  * Project URL: http://web.engr.orst.edu/~tateb/webView.php?
-->

<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connect to onid database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","tateb-db","uTwrzZZIqCgNJ5Nh","tateb-db");
if($mysqli->connect_errno) {
	echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html>
	<head>
		<title>Final Project</title>
	</head>
	<body>
        <div>
			<!--Render search form-->
    		<form id='searchForm' method='post' action='searchForm.php'>
    			<legend><b>Search for an artist to find connections to hometowns, genres, and more!</b></legend>
    			<fieldset>
    				<label>*Artist Name:
                        <select name='searchArt' required>
<!--Populate drop-down menu with MySQL query-->
<?php
//Select artist names and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT aid,fname,lname FROM artists ORDER BY fname,lname ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($aid,$fname,$lname)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu options from query results
while($stmt->fetch()){
    echo '<option value=" '. $aid . ' "> ' . $fname . 
    ' ' . $lname . '</option>\n';
}
$stmt->close();
?>
                        </select>
                    </label>
    				<br>
    				<input id='searchSub' type='submit' value='Search'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of artists table-->
    		<table id='artTbl' border='1'>
    			<caption><b><u>Artists</u></b></caption>
    			<thead>
    				<th>First Name</th>
    				<th>Last Name</th>
    			</thead>
    			<tbody>
<!--Populate table with MySQL query-->
<?php
//Select artist names from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT fname,lname FROM artists ORDER BY fname,lname ASC"))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($fname, $lname)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table rows from query results
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $fname . "</td>\n<td>" . $lname . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to artists table-->
    		<form id='artForm' method='post' action='artForm.php'>
    			<legend><b>Add an artist entry</b></legend>
    			<fieldset>
    				<label>*First Name:
    					<input name='artFName' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<label>*Last Name:
    					<input name='artLName' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<label>*Place of Birth:
                        <select name='artHome' required>
<!--Populate drop-down menu with MySQL query-->
<?php
//Select hometown cities, countries, and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT hid,city,country FROM hometowns ORDER BY city ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($hid,$city,$country)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu from query results
while($stmt->fetch()){
    echo '<option value=" '. $hid . ' "> ' . $city . 
    ', ' . $country . '</option>\n';
}
$stmt->close();
?>
                        </select>
    				</label>
    				<br>
    				<label>*Primary Genre:
                        <select name='artGen' required>
<!--Populate drop-down menu with MySQL query-->  
<?php
//Select genres and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT gid,genre FROM genres ORDER BY genre ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($gid,$genre)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu options from query results 
while($stmt->fetch()){
    echo '<option value=" '. $gid . ' "> ' . $genre . '</option>\n';
}
$stmt->close();
?>
                        </select>
    				</label>
    				<br>
    				<input id='artSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of genres table-->
    		<table id='genTbl' border='1'>
    			<caption><b><u>Genres</u></b></caption>
    			<thead>
    				<th>Genre Name</th>
    			</thead>
    			<tbody>
<!--Populate table with MySQL query-->
<?php
//Select genre names from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT genre FROM genres ORDER BY genre ASC"))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($genre)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table rows from query results 
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $genre . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to genres table--> 
    		<form id='genForm' method='post' action='genForm.php'>
    			<legend><b>Add a genre entry</b></legend>
    			<fieldset>
    				<label>*Genre Name:
    					<input name='genName' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<input id='genSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of hometowns table-->
    		<table id='homeTbl' border='1'>
    			<caption><b><u>Hometowns</u></b></caption>
    			<thead>
    				<th>City</th>
    				<th>Country</th>
    				<th>Current Population</th>
    			</thead>
    			<tbody>
<!--Populate table with MySQL query-->
<?php
//Select cities, countries and populations from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT city,country,current_pop FROM hometowns ORDER BY country,city ASC"))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($city, $country, $current_pop)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table from query results
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $city . "</td>\n<td>" . $country . "</td>\n<td>" . $current_pop . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to hometowns table--> 
			<form id='homeForm' method='post' action='homeForm.php'>
    			<legend><b>Add a hometown entry</b></legend>
    			<fieldset>
    				<label>*City:
    					<input name='homeCity' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<label>*Country:
    					<input name='homeCountry' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<label>*Current Population:
    					<input name='homePop' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<input id='homeSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of instruments table--> 
			<table id='instTbl' border='1'>
    			<caption><b><u>Instruments</u></b></caption>
    			<thead>
    				<th>Instrument Name</th>
    			</thead>
				<tbody>
<!--Populate table with MySQL query-->
<?php
//Select instrument names from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT instrument FROM instruments ORDER BY instrument ASC"))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($instrument)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table rows from query results 
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $instrument . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to instruments table--> 
			<form id='instForm' method='post' action='instForm.php'>
    			<legend><b>Add an instrument entry</b></legend>
    			<fieldset>
    				<label>*Instrument Name:
    					<input name='instName' type='text' maxlength='50' required>
    				</label>
    				<br>
    				<input id='instSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of art_inst table--> 
			<table id='artInstTbl' border='1'>
    			<caption><b><u>Artists' Instruments</u></b></caption>
    			<thead>
    				<th>First Name</th>
    				<th>Last Name</th>
    				<th>Instrument</th>
    				<th>Main?</th>
    			</thead>
				<tbody>
<!--Populate table with MySQL query-->
<?php
//Select all combinations of artists and instruments from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare(
    "SELECT fname,lname,instrument,main FROM " . 
    "(SELECT * FROM artists a INNER JOIN " . 
    "(SELECT * FROM art_inst) AS ai ON ai.ai_aid=a.aid INNER JOIN " . 
    "(SELECT * FROM instruments) AS i ON ai.ai_iid=i.iid) AS tbl " .  
    "ORDER BY fname, lname ASC"
))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($fname,$lname,$instrument,$main)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table rows from query results 
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $fname . "</td>\n<td>" . $lname . 
         "</td>\n<td>" . $instrument . "</td>\n<td>" . $main . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to art_inst table--> 
			<form id='artInstForm' method='post' action='artInstForm.php'>
    			<legend><b>Add an artist's instrument</b></legend>
    			<fieldset>
                    <label>*Artist:
                        <select name='artInstArt' required>
<!--Populate drop-down menu with MySQL query--> 
<?php
//Select artist names and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT aid,fname,lname FROM artists ORDER BY fname,lname ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($aid,$fname,$lname)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu from query results
while($stmt->fetch()){
    echo '<option value=" '. $aid . ' "> ' . $fname . 
    ' ' . $lname . '</option>\n';
}
$stmt->close();
?>
                        </select>
    				</label>
    				<br>
    				<label>*Instrument:
                        <select name='artInstInst' required>
<!--Populate drop-down menu with MySQL query-->  
<?php
//Select instrument names and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT iid,instrument FROM instruments ORDER BY instrument ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($iid,$instrument)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
while($stmt->fetch()){
    echo '<option value=" '. $iid . ' "> ' . $instrument . '</option>\n';
}
//Build menu from query results
$stmt->close();
?>
                        </select>
    				</label>
    				<br>
    				<label>
    					<input name='artInstMain' type='radio' value='1' checked='true'>Main Instrument
                    </label>
                    <label>
                        <input name='artInstMain' type='radio' value='0'>Secondary Instrument
    				</label>
    				<br>
    				<input id='artInstSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
    		<br>
			<!--Render display of inspirations table-->  
			<table id='inspTbl' border='1'>
    			<caption><b><u>Inpirations</u></b></caption>
    			<thead>
    				<th colspan='2'>Inspiring Artist</th>
    				<th colspan='2'>Inspired Artist</th>
    			</thead>
    			<tbody>
    				<tr>
    					<td><b>First Name</b></td>
    					<td><b>Last Name</b></td>
    					<td><b>First Name</b></td>
    					<td><b>Last Name</b></td>
    					<td><b>Relationship</b></td>
    				</tr>
<!--Populate table with MySQL query-->
<?php
//Select all combinations of inspired and luminary artists from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare(
    "SELECT lfname, llname, ifname, ilname, relationship FROM " . 
    "(SELECT aid AS laid, fname AS lfname, lname AS llname, relationship, iaid, ifname, ilname " . 
    "FROM artists l INNER JOIN " . 
    "(SELECT * FROM inspirations insp INNER JOIN " . 
    "(SELECT aid AS iaid, fname AS ifname, lname AS ilname FROM artists) " . 
    "AS i ON insp.inspired = i.iaid) " . 
    "AS tbl1 ON tbl1.luminary = l.aid) " . 
    "AS tbl2 " . 
    "ORDER BY lfname,llname ASC"
))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->execute()) {
    echo "Execute failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($lfname,$llname,$ifname,$ilname,$relationship)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;              
}
//Build table rows from query results
while($stmt->fetch()) {
    echo "<tr>\n<td>" . $lfname . "</td>\n<td>" . $llname . 
         "</td>\n<td>" . $ifname . "</td>\n<td>" . $ilname . 
         "</td>\n<td>" . $relationship . "</td>\n</tr>\n";
}
$stmt->close();
?>
    			</tbody>
    		</table>
    		<br>
			<!--Render form to add to inspirations table-->
			<form id='inspForm' method='post' action='inspForm.php'>
    			<legend><b>Add inspirations</b></legend>
    			<fieldset>
                    <label>*Inspiring Artist:
                        <select name='inspLum' required>
<!--Populate drop-down menu with MySQL query-->
<?php
//Select artist names and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT aid,fname,lname FROM artists ORDER BY fname,lname ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($aid,$fname,$lname)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu from query results
while($stmt->fetch()){
    echo '<option value=" '. $aid . ' "> ' . $fname . 
    ' ' . $lname . '</option>\n';
}
$stmt->close();
?>
                        </select>
    				</label>
                    <br>
                    <label>*Inspired Artist:
                        <select name='inspInsp' required>
<!--Populate drop-down menu with MySQL query--> 
<?php
//Select artist names and ids from database and bind results to variables, springing errors if needed
if(!($stmt = $mysqli->prepare("SELECT aid,fname,lname FROM artists ORDER BY fname,lname ASC"))){
    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!$stmt->bind_result($aid,$fname,$lname)){
    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build menu from query results
while($stmt->fetch()){
    echo '<option value=" '. $aid . ' "> ' . $fname . 
    ' ' . $lname . '</option>\n';
}
$stmt->close();
?>
                        </select>
    				</label>
                    <br>
        			<label>Relationship:
        				<input name='inspRel' type='text' maxlength='50'>
        			</label>
    				<br>
    				<input id='inspSub' type='submit' value='Submit'>
    			</fieldset>
    		</form>
        </div>
	</body>
</html>

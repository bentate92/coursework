<!--
  * Name: Benjamin Tate
  * Date: 8/7/2016
  * Assignment: CS340 - Final Project
  * Filename: searchForm.php
  * Description: Web page to handle the search function and display results
  * Project URL: http://web.engr.orst.edu/~tateb/webView.php?
-->

<?php
//Turn on error reporting
ini_set('display_errors', 'On');
//Connect to onid database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","tateb-db","uTwrzZZIqCgNJ5Nh","tateb-db");
if($mysqli->connect_errno) {
	echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
?>

<!--Begin description list-->
<dl>
<?php
//Build query to select name, hometown, and genre of given artist from database
$query = 
    "SELECT fname,lname,city,country,genre FROM " . 
    "(SELECT * FROM genres g INNER JOIN " . 
    "(SELECT aid, fname, lname, hometown, genre AS genreId FROM artists a " . 
    "WHERE a.aid=?" . 
    ") AS tbl1 ON tbl1.genreId = g.gid INNER JOIN " . 
    "(SELECT * FROM hometowns" . 
    ") AS h ON h.hid = tbl1.hometown" . 
	") AS tbl2";
//Run query and spring errors if needed
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($fname,$lname,$city,$country,$genre)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build sections of list from query results
while($stmt->fetch()){
    echo "<dt><b>Name:</b></dt>\n<dd>" . $fname . " " . $lname . "</dd>\n" . 
         "<dt><b>Birthplace:</b></dt>\n<dd>" . $city . ", " . $country . "</dd>\n" . 
         "<dt><b>Primary Genre:</b></dt>\n<dd>" . $genre . "</dd>";
}
$stmt->close();

//Build query to select number of instruments played by given artist
$query = 
    "SELECT COUNT(instrument) AS instCount FROM " . 
    "(SELECT * FROM artists a INNER JOIN " . 
    "(SELECT * FROM art_inst" . 
    ") AS ai ON ai.ai_aid = a.aid INNER JOIN " . 
    "(SELECT * FROM instruments " . 
    ") AS i ON ai.ai_iid = i.iid" . 
	") AS tbl WHERE tbl.aid = ? GROUP BY fname";
//Run query and spring errors if needed
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($instCount)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dt><b>Plays " . $instCount . " instruments:</b></dt>";
}
$stmt->close();
?>
<dd>
	<!--Begin sublist for main instruments-->
    <dt>Mains:</dt>
<?php
//Build query to select main instruments played by given artist
$query = 
    "SELECT instrument,main FROM " . 
    "(SELECT * FROM artists a INNER JOIN " . 
    "(SELECT * FROM art_inst" . 
    ") AS ai ON ai.ai_aid = a.aid INNER JOIN " . 
    "(SELECT * FROM instruments " . 
    ") AS i ON ai.ai_iid = i.iid" . 
    ") AS tbl WHERE tbl.aid = ? AND tbl.main = '1'";
//Run query and spring errors if needed
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($instrument,$main)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dd>" . $instrument . "</dd>";
}
$stmt->close();
?>
</dd>
<dd>
	<!--Begin sublist for secondary instruments-->
    <dt>Secondaries:</dt>
<?php
//Build query to select secondary instruments played by given artist
$query = 
    "SELECT instrument,main FROM " . 
    "(SELECT * FROM artists a INNER JOIN " . 
    "(SELECT * FROM art_inst" . 
    ") AS ai ON ai.ai_aid = a.aid INNER JOIN " . 
    "(SELECT * FROM instruments " . 
    ") AS i ON ai.ai_iid = i.iid" . 
    ") AS tbl WHERE tbl.aid = ? AND tbl.main = '0'";
//Run query and spring errors if needed
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($instrument,$main)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dd>" . $instrument . "</dd>";
}
$stmt->close();
?>
</dd>
<?php
//Build query to select number of artists inspired by given artist
$query = 
    "SELECT COUNT(iaid) AS lumCount FROM " . 
    "(SELECT aid AS laid, fname AS lfname, lname AS llname, relationship, iaid, ifname, ilname " .  
    "FROM artists l INNER JOIN " . 
    "(SELECT * FROM inspirations insp INNER JOIN " . 
    "(SELECT aid AS iaid, fname AS ifname, lname AS ilname FROM artists" . 
    ") AS i ON insp.inspired = i.iaid" . 
    ") AS tbl1 ON tbl1.luminary = l.aid WHERE tbl1.luminary=?" . 
	") AS tbl2 GROUP BY lfname";
//Run query and spring errors if needed 
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($lumCount)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dt><b>Inspired " . $lumCount . " other artists:</b></dt>";
}
$stmt->close();
//Build query to select names of artists inspired by given artist
$query = 
    "SELECT ifname,ilname FROM " . 
    "(SELECT aid AS laid, fname AS lfname, lname AS llname, relationship, iaid, ifname, ilname " .  
    "FROM artists l INNER JOIN " . 
    "(SELECT * FROM inspirations insp INNER JOIN " . 
    "(SELECT aid AS iaid, fname AS ifname, lname AS ilname FROM artists" . 
    ") AS i ON insp.inspired = i.iaid" . 
    ") AS tbl1 ON tbl1.luminary = l.aid WHERE tbl1.luminary=?" . 
	") AS tbl2";
//Run query and spring errors if needed 
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($ifname,$ilname)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dd>" . $ifname . " " . $ilname . "</dd>";
}
$stmt->close();
//Build query to select number of artists that inspired given artist
$query = 
    "SELECT COUNT(laid) AS inspCount FROM " . 
    "(SELECT aid AS laid, fname AS lfname, lname AS llname, relationship, iaid, ifname, ilname " .  
    "FROM artists l INNER JOIN " . 
    "(SELECT * FROM inspirations insp INNER JOIN " . 
    "(SELECT aid AS iaid, fname AS ifname, lname AS ilname FROM artists" . 
    ") AS i ON insp.inspired = i.iaid" . 
    ") AS tbl1 ON tbl1.luminary = l.aid WHERE tbl1.inspired=?" . 
    ") AS tbl2 GROUP BY ifname";
//Run query and spring errors if needed  
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($inspCount)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results 
while($stmt->fetch()) {
    echo "<dt><b>Inspired by " . $inspCount . " other artists:</b></dt>";
}
$stmt->close();
//Build query to select names of artists that inspired given artist
$query = 
    "SELECT lfname,llname FROM " . 
    "(SELECT aid AS laid, fname AS lfname, lname AS llname, relationship, iaid, ifname, ilname " .  
    "FROM artists l INNER JOIN " . 
    "(SELECT * FROM inspirations insp INNER JOIN " . 
    "(SELECT aid AS iaid, fname AS ifname, lname AS ilname FROM artists" . 
    ") AS i ON insp.inspired = i.iaid" . 
    ") AS tbl1 ON tbl1.luminary = l.aid WHERE tbl1.inspired=?" . 
	") AS tbl2";
//Run query and spring errors if needed  
if(!($stmt = $mysqli->prepare($query))) {
    echo "Prepare failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if(!($stmt->bind_param("i",$_POST['searchArt']))) {
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->bind_result($lfname,$llname)) {
    echo "Bind failed: " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
//Build section of list from query results  
while($stmt->fetch()) {
    echo "<dd>" . $lfname . " " . $llname . "</dd>";
}
$stmt->close();
?>
</dl>
<!--Render back button-->
<form id='back' method='get' action='webView.php'>
    <input id='submit' type='submit' value='Back'>
</form>

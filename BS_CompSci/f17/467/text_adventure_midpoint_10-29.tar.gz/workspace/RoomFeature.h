//
//  RoomFeature.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/27/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef ROOMFEATURE_H
#define ROOMFEATURE_H

#include <stdio.h>
#include "InteractiveObject.h"

using namespace std;

class RoomFeature : public InteractiveObject
{
private:
    
public:
    
    
};

#endif

//
//  Game.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "Game.h"

//constructor
Game::Game( vector<Room> &rooms, vector<Item> &inventory )
{
    gameRooms = &rooms;
    inventoryList = &inventory;
    for( int i = 0; i < static_cast <int>(rooms.size()); i++ )
    {
        if( rooms[i].getIsCurrentRoom() == true )
        {
            currentRoom = &rooms[i];
        }
    }
}

//destructor
Game::~Game( )
{
    
}

//Set the current direction the user is facing.
void Game::setUserDirection( string userDirection )
{
    
}

//Set the user’s inventory list.
void Game::setInventoryList( Item* inventoryItem )
{
    
}

//Set the current floor level that the user is on.
void Game::setCurrentFloorLevel( string currentFloorLevel )
{
    
}

//Set the current room that the user is currently in.
void Game::setCurrentRoom( Room* currentRoom )
{
    this->currentRoom = currentRoom;
}

//Set the current location of the user within a room.
void Game::setCurrentLocation( string currentLocation )
{
    
}

//Set the rooms the user has already visited.
void Game::setRoomsVisited( Room visitedRooms )
{
    
}

//Set the locations for all of the game’s objects.
void Game::setItemLocations( string itemLocation )
{
    
}

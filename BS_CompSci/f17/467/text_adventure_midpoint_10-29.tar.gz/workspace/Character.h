//
//  Character.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/21/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef CHARACTER_H
#define CHARACTER_H

#include <stdio.h>
#include <vector>
#include <string>

using namespace std;

class Character
{
    private:
        //The name of the character
        string characterName;
    
        //The description of the character.
        string characterDescription;
    
        //Friend or foe?
        bool isFriend;
    
    public:
        //Default constructor. Create one with parameters if needed.
        Character( );
    
        //Default destructor
        ~Character( );
    
        //Get the character name
        string getCharacterName( )
        {
            return characterName;
        }
    
        //Get the character description.
        string getCharacterDescription( )
        {
            return characterDescription;
        }
    
        //Get friend or foe state
        bool getIsFriend( )
        {
            return isFriend;
        }
    
        //Set the character name
        void setCharacterName( string characterName );
    
        //Set the character description.
        void setCharacterDescription( string characterDescription );
    
        //Set friend or foe state
        void setIsFriend( bool isFriend );
};

#endif 

//
//  spaceAdventure.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/22/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "spaceAdventure_helpers.h"
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>



void gameInit( vector<Room> &rooms, vector<Item> &items, vector<Item> &inventory )
{
    //Game gameState( rooms, inventory );
}

void loadRooms(vector<Room> &rooms, vector<Door> &doors, vector<Item> &items, vector<RoomFeature> &features)
{
    //**************Code partially sourced from http://www.cplusplus.com/forum/general/31436/****************
    string fileName;
    string tempString;
    string delimiter = "#";
    string dName, dDescrip, iName, iDescrip, iUse, fName, fDescrip;
    int dState;
    //int dLocation;
    int iCanInv;
    size_t pos = 0;
    bool found = false;
    
    
    for(int i = 0; i < 3; i++)
    {
        //Create an output string stream that will hold the current file name of the room file to be read in.
        ostringstream ss;
        ss << "room_" << i << ".txt";
        
        //Create a file stream object and link it to the current room file.
        ifstream inputFile(ss.str().c_str());
        
        //Create a new room object from each room text file.
        if (!inputFile)
        {
            cout << "Could not open the file" << endl;
        }
            
        //Create a new room object and add it to the rooms vector.
        Room room;
        rooms.push_back(room);
        
            
        //Read in the room file, parse the data, and then populate the member variables of the newly created room
        //object with the parsed data.
        getline(inputFile, fileName, '$');
        while(!inputFile.fail())
        {
            if( fileName == "RoomName" )
            {
                //cout << "Entering roomName block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setRoomName( fileName );
                //cout << "Exiting rn block." << endl << endl;
            }
            else if( fileName == "LDescript" )
            {
                //cout << "Entering long descrip block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setLongFormDescrip( fileName );
                //cout << "Exiting ld block." << endl << endl;
            }
            else if( fileName == "ModLDescript" )
            {
                //cout << "Entering mod long descrip block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setModLongFormDescrip( fileName );
                //cout << "Exiting mld block." << endl << endl;
            }
            else if( fileName == "SDescript" )
            {
                //cout << "Entering sh descrip block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setShortFormDescrip( fileName );
                //cout << "Exiting sd block." << endl << endl;
            }
            else if( fileName == "ModSDescript" )
            {
                //cout << "Entering mod sh descrip block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setModShortFormDescrip( fileName );
                //cout << "Exiting msd block." << endl << endl;
            }
            else if( fileName == "AddExplan" )
            {
                //cout << "Entering add. explan block." << endl;
                getline( inputFile, fileName, '$' );
                rooms[i].setAdditionalExplanation( fileName );
                //cout << "Exiting ae block." << endl << endl;
            }
            else if( fileName == "Doors" )
            {
                //cout << "Entering doors block." << endl;
                getline( inputFile, fileName, '$' );
                //Parse the door names.
                //Referenced from https://stackoverflow.com/questions/14265581/parse-split-a-string-in-c-using-string-delimiter-standard-c
                while( ( pos = fileName.find( delimiter ) ) != string::npos )
                {
                    dName = fileName.substr( 0, pos );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    dDescrip  = fileName.substr( 0, pos );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    dState  = stoi( ( fileName.substr( 0, pos ) ) );
                    fileName.erase( 0, pos + delimiter.length() );
                    //pos = fileName.find( delimiter );
                    //dLocation  = stoi( ( fileName.substr( 0, pos ) ) );
                    
                    //If the doors vector is empty then create a new door object and add it to it. Pass a pointer to the
                    //door object to the room's door vector member.
                    //Iterate through the doors vector and check to see if the door object has already been created.
                    //If it has, then pass the pointer to the room's door member vector.
                    //If not, create a new door object, add it to the doors vector, then pass a pointer to the room's door vector member.
                    if( doors.size() == 0 )
                    {
                        Door door;
                        doors.push_back( door );
                        doors[0].setName( dName );
                        doors[0].setDescription( dDescrip );
                        doors[0].setDoorState( dState );
                        //doors[0].setLocation( dLocation );
                        rooms[i].setDoorsInRoom( &doors[0] );
                    }
                    else
                    {
                        //********For loop still needs to be tested.***********
                        int vectSize = static_cast<int>( doors.size() );
                        for(int j = 0; j < vectSize; j++)
                        {
                            if( dName == doors[j].getName() )
                            {
                                rooms[i].setDoorsInRoom( &doors[j] );
                                found = true;
                                break;
                            }
                        }
                        if( found == false )
                        {
                            Door door;
                            doors.push_back( door );
                            doors[vectSize].setName( dName );
                            doors[vectSize].setDescription( dDescrip );
                            doors[vectSize].setDoorState( dState );
                            rooms[i].setDoorsInRoom( &doors[vectSize] );
                        }
                        found = false;
                    }
                    dName = "";
                    dDescrip = "";
                    fileName.erase( 0, pos + delimiter.length() );
                    getline( inputFile, fileName, '$' );
                    
                    
                }
                //cout << "Exiting doors block." << endl << endl;
            }
            else if( fileName == "Items" )
            {
                //cout << "Entering items block." << endl;
                getline( inputFile, fileName, '$' );
                //Parse the door names.
                while( ( pos = fileName.find( delimiter ) ) != string::npos )
                {
                    iName = fileName.substr( 0, pos );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    iDescrip  = fileName.substr( 0, pos );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    iCanInv  = stoi( (fileName.substr( 0, pos) ) );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    iUse  = fileName.substr( 0, pos );
                    
                    //If the items vector is empty then create a new item object and add it to it. Pass a pointer to the
                    //item object to the room's item vector member.
                    //Iterate through the items vector and check to see if the item object has already been created.
                    //If it has, then pass the pointer to the room's item member vector.
                    //If not, create a new item object, add it to the item vector, then pass a pointer to the room's item vector member.
                    if( items.size() == 0 )
                    {
                        Item item;
                        items.push_back( item );
                        items[0].setName( iName );
                        items[0].setDescription( iDescrip );
                        items[0].setCanInventory( iCanInv );
                        items[0].setItemUse( iUse );
                        items[0].setLocation( &rooms[i] );
                        rooms[i].setItem( &items[0] );
                    }
                    else
                    {
                        //********For loop still needs to be tested.***********
                        int vectSize = static_cast<int>( items.size() );
                        for( int j = 0; j < vectSize; j++ )
                        {
                            if( iName == items[j].getName() )
                            {
                                rooms[i].setItem( &items[j] );
                                found = true;
                                break;
                            }
                        }
                        if( found == false )
                        {
                            Item item;
                            items.push_back( item );
                            items[vectSize].setName( iName );
                            items[vectSize].setDescription( iDescrip );
                            items[vectSize].setCanInventory( iCanInv );
                            items[vectSize].setItemUse( iUse );
                            items[vectSize].setLocation( &rooms[i] );
                            rooms[i].setItem( &items[vectSize] );
                        }
                        found = false;
                    }
                    iName = "";
                    iDescrip = "";
                    iUse = "";
                    fileName.erase( 0, pos + delimiter.length() );
                    getline( inputFile, fileName, '$' );
                    
                    
                }
                //cout << "Exiting items block." << endl << endl;
            }
            else if( fileName == "Features" )
            {
                //cout << "Entering features block." << endl;
                getline( inputFile, fileName, '$' );
                //Parse the door names.
                while( ( pos = fileName.find( delimiter ) ) != string::npos )
                {
                    fName = fileName.substr( 0, pos );
                    fileName.erase( 0, pos + delimiter.length() );
                    pos = fileName.find( delimiter );
                    fDescrip  = fileName.substr( 0, pos );
                    
                    //If the features vector is empty then create a new feature object and add it to it. Pass a pointer to
                    //the feature object to the room's feature vector member.
                    //Iterate through the feature vector and check to see if the feature object has already been created.
                    //If it has, then pass the pointer to the room's feature member vector.
                    //If not, create a new feature object, add it to the feature vector, then pass a pointer to the room's feature vector member.
                    if( features.size() == 0 )
                    {
                        RoomFeature rFeature;
                        features.push_back( rFeature );
                        features[0].setName( fName );
                        features[0].setDescription( fDescrip );
                        rooms[i].setRoomFeature( &features[0] );
                    }
                    else
                    {
                        //********For loop still needs to be tested.***********
                        int vectSize = static_cast<int>( features.size() );
                        for( int j = 0; j < vectSize; j++ )
                        {
                            if( fName == features[j].getName() )
                            {
                                rooms[i].setRoomFeature( &features[j] );
                                found = true;
                                break;
                            }
                        }
                        if( found == false )
                        {
                            RoomFeature rFeature;
                            features.push_back( rFeature );
                            features[vectSize].setName( fName );
                            features[vectSize].setDescription( fDescrip );
                            //features[vectSize].setLocation( &rooms[i] );
                            rooms[i].setRoomFeature( &features[vectSize] );
                        }
                        found = false;
                    }
                    fName = "";
                    fDescrip = "";
                    fileName.erase( 0, pos + delimiter.length() );
                    getline( inputFile, fileName, '$' );
                    
                    
                }
                //cout << "Exiting features block." << endl << endl;
            }
            else if( fileName == "isCurrentRoom" )
            {
                //cout << "Entering currentRoom block." << endl;
                rooms[i].setIsCurrentRoom( true );
                //cout << "Exiting cr block." << endl << endl;
            }
            else if( fileName == "")
            {
                //cout << "Entering empty string block" << endl;
                break;
            }
            else
            {
                cout << "Error reading file!" << endl;
            }
            
            getline( inputFile, fileName, '$' );
            
    
        }
        //rooms[i].setLongFormDescrip( fileName );
        cout << endl;
        
        
        inputFile.close();
        //cout << "Exiting  file block." << endl << endl;
    }
}

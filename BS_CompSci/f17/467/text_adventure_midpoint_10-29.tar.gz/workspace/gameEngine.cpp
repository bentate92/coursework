//
//  main.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include "Game.h"
#include "Door.h"
#include "Room.h"
#include "InteractiveObject.h"
#include "Item.h"
#include "Character.h"
#include "spaceAdventure_helpers.h"
#include "RoomFeature.h"
#include "Command.h"

using namespace std;

int main(int argc, const char * argv[]) {
    
    string gameMenuChoice;
    vector<Door> doors;
    vector<Room> rooms;
    vector<Item> items;
    vector<RoomFeature> features;
    vector<Item> inventory;
    
    
    doors.reserve(100);
    rooms.reserve(100);
    items.reserve(100);
    features.reserve(100);
    inventory.reserve(100);
    
    
    //*****************************************TITLE SCREEN****************************************
    
    cout<<"GAME TITLE"<<endl<<endl;
    cout<<"Created by: David Marini, Alan Seims, and Benjamin Tate"<<endl<<endl;
    
    
    
    
    
    //*****************************************GAME MENU*******************************************
    
    cout<<"What would you like to do?"<<endl;
    cout<<"1) New Game"<<endl;
    cout<<"2) Load Game"<<endl;
    cout<<"3) Exit"<<endl;
    cout<<">> ";
    
    getline(cin, gameMenuChoice);
    
    transform(gameMenuChoice.begin(), gameMenuChoice.end(), gameMenuChoice.begin(), ::tolower);
    Game gameState( rooms, inventory );
    while(1)
    {
        if(gameMenuChoice == "1" || gameMenuChoice == "new game" || gameMenuChoice == "new")
        {
            //Pass the vector of room objects.
            //Load the room files into the Room objects.
            loadRooms( rooms, doors, items, features );
            //gameInit( rooms, items, inventory );
            //**********Remove after demonstration************
            doors[0].setConnectingRooms(&rooms[1]);
            doors[0].setConnectingRooms(&rooms[2]);
            //cout << "test" << endl;
            //cout << (doors[0].getConnectingRooms())[0]->getRoomName() << endl;
            //cout << (doors[0].getConnectingRooms())[1]->getRoomName() << endl;
            //cout << "end test" << endl;
            gameState.setCurrentRoom(&rooms[1]);
            
            //Pass the vector of room objects.
            //Initialize a new game.
            //Game gameState( rooms, inventory );
            //gameInit( &gameState, rooms, items, inventory );
            //cout << "Here" << endl;
            
            //********************************OPENING INTRO****************************************
            //Read in the opening intro file.
                //pg. 375
            
            
            break;
        }
        else if(gameMenuChoice == "2" || gameMenuChoice == "load game" || gameMenuChoice == "load")
        {
            //loadGame( );
            break;
        }
        else if(gameMenuChoice == "3" || gameMenuChoice == "Exit")
        {
            //exitProgram( );
                //pg. 382
        }
        else {
            cout<<"Invalid Input. Try Again!"<<endl;
        }
    }
    
    
    
    
    //*****************************************MAIN GAME LOOP*******************************************
    //Load the current room
    
    //Check to see if the current room is the end of game file.
    
    //Has the room been previously visited?
    
        //Display the necessary description.
    
    //Wait for, and read in, user input.
    
    //Verify if command is valid.
    
    //Parse user input.
    
    cout << "Your ship careens to the surface of an unknown planet.\n" << endl;
    cout << "WARNING, WARNING, IMPACT SYSTEMS OFFLINE\n" << endl;
    cout << "The sound of the atmosphere around you is just loud enough to prevent you from hearing the rattling of the clunk of metal that is barely holding together.\n" << endl;
    cout << "WARNING, WARNING, CHANCE OF SURVIVAL CALCULATED AT 0.0001%\n" << endl;
    cout << "Your life flashes before your eyes moments before impact, strangely your last thought is going to be about that one time you puked in 4th grade.\n" << endl;
    cout << "BOOM\n" << endl;
    cout << "The impact makes a huge sound around you as you wait for what you imagine is going to be a painful death. Either your ship had the dumbest AI or you are that lucky one in a billion. You push on the door and it falls to the ground, just off in the distance you see an outpost.\n" << endl;
    cout << "You climb out of the ship without so much as a scratch and wonder over to the outpost. Right as you open the front door you hear an explosion. You turn around to see a small mushroom cloud over what used to be your ship.\n" << endl;
    cout << "Well we aren’t leaving the way we came, you think to yourself. You open the door and step into the outpost.\n" << endl; 
    
    cout << ((gameState.getCurrentRoom())->getLongFormDescrip()) << endl;
    
    while (1) {
        Room* curr_room = gameState.getCurrentRoom();
        
	    string userInput;
	    string verb;
	    string noun;
	    vector<string> inv = make_list(&gameState, "inventory");
	    string nextCommand = "Enter command:\n>> ";
	    //Ask the user what they would like to do
	    cout << nextCommand;
	    //Read the line into action string
	    getline(cin, userInput);
	    //Parse and validate users input
	    string action = command(&gameState, userInput);
	    
	    //Print for debugging
	    cout << "action = " << action << endl;
	    
	    //Section the command passed
	    section_command(action, &verb, &noun);
	    cout << "After section_command()\n";
	    //Pass the section command with the game state to get a returned string 
	    string actionTaken = actionRoom(verb, noun, curr_room, inv, &gameState);
	    cout << "After actionRoom()\n";
	    //Print the outpot of the action
	    cout << actionTaken << endl;
    }
    
    return 0;
}

#include <iostream>
#include <string>
#include <vector> 
#include <algorithm> //not in plan
#include <cctype>
#include <stdlib.h> //Not in plan
#include "Game.h"
#include "Command.h"
#include "Door.h"

using namespace std;

//Ben:  My thoughts on how this will work:
//	This will get the command only after it has been validated.
//	command will be split as <word1>:<word2>
//	If word1 == "INVAL" -> print word2
//	If word1 == "NONE" -> verb should be treated as "go"
//	If word2 == "NONE" -> word1 is something like help, savegame, etc., which doesn't need a noun.
void section_command(string command, string* word1, string* word2){
	string tempStr;
	vector<string> words;
	char search = ':';
	//Splits up our command into a vector
	for(int i = 0; i < static_cast<int>(command.size()); i++){
		//If we haven't reached :
		if(command.at(i) != search){
			//Add that character onto the vector
			tempStr.insert(tempStr.end(), command.at(i));
		}
		//If we reach the end of the passed command
		if(i == static_cast<int>(command.size()) -1){
			//Push the temporary string onto the word vector
			words.push_back(tempStr);
			tempStr.clear();
		}
		//If we found the :
		if(command.at(i) == search){
			//Push the temporary string onto the word vector
			words.push_back(tempStr);
			tempStr.clear();
		}
	}
	if(words.size() == 2){
		*word1 = words.at(0);
		*word2 = words.at(1);
	}
	else {
		cout << "Invalid Command" <<endl;
	}
}

string actionRoom(string verb, string noun, Room* curr_room, vector<string> inv, Game* game){
	string nextCommand = "What would you like to do?";
	int i; 
	//If there is no verb assume they are trying to go
	if(verb == "NONE"){
		verb = "go";
	}
	//If we didn't get a valid function, return an error.
	if(verb == "INVAL"){
		return noun;
	}
	else if (verb == "help"){
		//Print a list of our verbs
		cout << "HELP - Will list the commands you can typically use." << endl;
		cout << "LOOK - Tells you a short description of the room you are in." << endl;
		//cout << "LOOK AT (NOUN) - Will tell you a bit about the thing you are looking at if it is observable." << endl;
		cout << "GO (ROOM NAME) - Moves you to the room if it is attached to where you are." << endl;
		//cout << "TAKE (ITEM) - Will pick up the item if you are able to carry it." << endl;
		//cout << "DROP (ITEM) - Will drop the item if it is in your inventory." << endl;
		//cout << "USE (ITEM) - Will use the item in the current room if possible." << endl;
		cout << "INVENTORY - Will list your current inventory." << endl;
		//cout << "SAVEGAME - Will save your current place in the game." << endl;
		//cout << "LOADGAME - Will load previous saves of the game." << endl;
		return "QUIT - Will quit the game.";
	}
	else if(verb == "look"){
		//Print the short description of the room
		return curr_room->getLongFormDescrip(); 
	}
	/*else if(verb == "look at"){
		//If the item is in our inventory or the room, print the item description
		if(is_in(inv, noun) || is_in(curr_room, noun){
			return noun.itemDescription();
		}
	}*/
	else if(verb == "go"){
		//Make list of neighbors
		vector<Door*> neighborList = curr_room->getDoors();
		
		//Increment through all the doors in the room
		for(i = 0; i < static_cast<int>(curr_room->getNumDoors()); i++){
			//Which ever one matches
			if(noun == neighborList[i]->getName()){
				//Set to our current room
				if (curr_room == neighborList[i]->getConnectingRooms()[0]) {
					curr_room = neighborList[i]->getConnectingRooms()[1];
				} else {
					curr_room = neighborList[i]->getConnectingRooms()[0];
				}
				//Change the current room we are in
				game->setCurrentRoom(curr_room);
				//Check if the room has been visited
				//for(i = 0; i < roomsVisited.size; i++){
				//	if(curr_room == roomsVisited[i]){
						//If so, return the short form desriptionbg
				//		return curr_room->getShortFormDescrip();
				//	}
				//}
				//If the room has not been visited return the long form description of the next room
				return curr_room->getLongFormDescrip();
			}
		}
		
		return "How did we get here?";
	}
	/*else if(verb == "take"){
		//Check that we can put the noun within our inventory and its in the room
		for(i = 0; i < objectsInRoom.size(); i++){
			if(noun == objectsInRoom[i]){
				if(noun.getCanInventory()){
					//Put item into the inventory
					setInventory(noun);
					//Not 100% on how we are saying that a player has an item and it isn't in a room
					noun.setObjectLocation(//player);
					string taken = "You successfully acquired the " + noun;
					return taken;
				}
				else{
					return "That item cannot be taken."
				}
			}
			else{
				return "That isn't in this room."
			}
		}
	}
	else if(verb == "drop"){
		//If the item is in our inventory
		if(noun.is_in(inv)){
			//Gotta write this, but drop the item
			dropInventory(noun);
			//Set the location to the current room
			noun.setObjectLocation(curr_room);
			string dropped = noun + " is now sitting on the floor.";
			return dropped;
		}
	}
	else if(verb == "use"){
		//If we have the object in our inventory and can use it, do so.
		for(int i = 0; i < inventoryList.size(); i++){
			if(noun == inventoryList[i]){
				if(noun.canUseObject()){
					noun.getObjectUse();
					noun.setObjectUsed();
				};
			}
		}
	}*/
	else if(verb == "inventory"){
		//Used one of ben's functions to make the list
		vector<string> inventoryList = make_list(game, "inventory");
		//then just cycle through the list and print it
		for(int i = 0; i < static_cast<int>(inventoryList.size()); i++){
			cout << inventoryList[i] << endl;
			return "";
		}
		return "Your inventory is empty.";
	}
	//else if(verb == "savegame"){
		//save
	//}
	//else if(verb == "loadgame"){
		//load
	//}*/
	else if(verb == "quit"){
		//Ask user if they want to save first
		//cout << "Would you like to save the game?" << endl;
		//Quit the game 
		exit(EXIT_SUCCESS);
	}
	
	return "We shouldn't be here.";
}

//Function to simplify user command
string command(Game* g, string command) {
	string nType;
	string verb = "";
	string noun = "";
	string outCmd = "";
	
	//Lists of accepted words
	vector<string> verb_list = {
		"look at", "inspect", "investigate", "examine", "study",
		"look", "look around",
		"go", "head", "exit to", "travel", "walk", "move",
		"take", "pick up", "grab", "acquire", "obtain", "get",
		"help",
		"inventory", "bag", "pouch",
		"savegame", "save",
		"loadgame", "load",
		"use",
		"drop", "place", "put", "set", "discard",
		"quit", "exit", "quitgame", "exitgame"
	};
	vector<string> place_list = {
		"north", "south", "east", "west", 
		"level1hall1", "l1 hall 1", "level 1 hall 1", 
		"level1hall2", "l1 hall 2", "level 1 hall 2", 
		"warehouse", 
		"chowhall", "chow hall", "kitchen", "cafeteria",
		"pantry", 
		"medbay", "med bay", 
		"hangarbay", "hangar bay", "hangar", 
		"elevator", 
		"level2hall1", "l2 hall 1", "level 2 hall 1", 
		"level2hall2", "l2 hall 2", "level 2 hall 2", 
		"level2hall3", "l2 hall 3", "level 2 hall 3",
		"sleepingquarters", "sleeping quarters", 
		"offquarters1", "officer quarters 1", 
		"offquarters2", "officer quarters 2", 
		"offquarters3", "officer quarters 3", 
		"offquarters4", "officer quarters 4", 
		"offquarters5", "officer quarters 5", 
		"commanderquarters", "commander's quarters", "commander quarters", "commandersquarters",
		"level3hall1", "l3 hall 1", "level 3 hall 1", 
		"armory", 
		"controlroom", "control room", 
		"deck"
	};
	//TODO: make aliases
	vector<string> feature_list = {
		"l1 map", "flashing red light", "warehouse kiosk", "toolbox", "kitchen appliances", 
		"prep table", "footprints", "fridge", "supply cabinet", "gauze", "generator", "ship", "bay doors", "dead", "buttons",
		"l2 map", "foot locker", "bed", "notebook", "vent cover", "photo", "journal", "book", "badge", "mirror", "makeup", "barbell",
		"tablet", "charging station", "desk", "safe", "soap", "l3 map", "bars", "control console", "window", "guns", "schematics"
		
	};
	//TODO: make aliases
	vector<string> item_list = {
		"tubing", "elevator key", "commander's key", "warehouse code book", "navigation system", 
		"cleaver", "gun", "torch", "tank", "screwdriver"
	};

	//Convert command to all lowercase letters
	transform(command.begin(), command.end(), command.begin(), (int (*)(int))tolower);

	//Find verb
	for (vector<string>::iterator t = verb_list.begin(); t != verb_list.end(); ++t) {
		size_t found = command.find(*t);
		if (found != string::npos) {
			verb = *t;
			break;
		}
	}

	//Find feature
	for (vector<string>::iterator t = feature_list.begin(); t != feature_list.end(); ++t) {
		size_t found = command.find(*t);
		if (found != string::npos) {
			noun = *t;
			nType = "feature";
			break;
		}
	}

	//Find place
	for (vector<string>::iterator t = place_list.begin(); t != place_list.end(); ++t) {
		size_t found = command.find(*t);
		if (found != string::npos) {
			noun = *t;
			nType = "place";
			break;
		}
	}

	//Find item
	for (vector<string>::iterator t = item_list.begin(); t != item_list.end(); ++t) {
		size_t found = command.find(*t);
		if (found != string::npos) {
			noun = *t;
			nType = "item";
			break;
		}
	}
	
	//Set nType if no noun found
	if (noun == "") {
		nType = "none";
	}
	
	//Simplify place aliases
	if (nType == "place") {
		if (noun == "l1 hall 1" || noun == "level 1 hall 1") {
			noun = "level1hall1";
		} else if (noun == "l1 hall 2" || noun == "level 1 hall 2") {
			noun = "level1hall2";
		} else if (noun == "chow hall" || noun == "kitchen" || noun == "cafeteria") {
			noun = "chowhall";
		} else if (noun == "med bay") {
			noun = "medbay";
		} else if (noun == "hangar bay" || noun == "hangar") {
			noun = "hangarbay";
		} else if (noun == "l2 hall 1" || noun == "level 2 hall 1") {
			noun = "level2hall1";
		} else if (noun == "l2 hall 2" || noun == "level 2 hall 2") {
			noun = "level2hall2";
		} else if (noun == "l2 hall 3" || noun == "level 2 hall 3") {
			noun = "level2hall3";
		} else if (noun == "sleeping quarters") {
			noun = "sleepingquarters";
		} else if (noun == "officer quarters 1") {
			noun = "offquarters1";
		} else if (noun == "officer quarters 2") {
			noun = "offquarters2";
		} else if (noun == "officer quarters 3") {
			noun = "offquarters3";
		} else if (noun == "officer quarters 4") {
			noun = "offquarters4";
		} else if (noun == "officer quarters 5") {
			noun = "offquarters5";
		} else if (noun == "commander's quarters" || noun == "commander quarters" || noun == "commandersquarters") {
			noun = "commanderquarters";
		} else if (noun == "l3 hall 1" || noun == "level 3 hall 1") {
			noun = "level3hall1";
		} else if (noun == "control room") {
			noun = "controlroom";
		}
	}

	//Simplify verb aliases
	if (verb != "") {
		if (verb == "look around") {
			verb = "look";
		} else if (verb == "inspect" || verb == "investigate" || verb == "examine" || verb == "study") {
			verb = "look at";
		} else if (verb == "head" || verb == "exit to" || verb == "travel" || verb == "walk" || verb == "move") {
			verb = "go";
		} else if (verb == "pick up" || verb == "grab" || verb == "acquire" || verb == "obtain" || verb == "get") {
			verb = "take";
		} else if (verb == "bag" || verb == "pouch") {
			verb = "inventory";
		} else if (verb == "save") {
			verb = "savegame";
		} else if (verb == "load") {
			verb = "loadgame";
		} else if (verb == "place" || verb == "put" || verb == "set" || verb == "discard") {
			verb = "drop";
		} else if (verb == "exit" || verb == "quitgame" || verb == "exitgame") {
			verb = "quit";
		}
	} 

	cout << "Before validate()" << endl;
	outCmd = validate(g, verb, noun, nType);
	cout << "After validate()" << endl;

	return outCmd;
}

string validate(Game* game, string verb, string noun, string nType) {
	Room currRoom = game->getCurrentRoom();
	vector<string> inventory = make_list(game, "inventory");
	vector<string> items = make_list(game, "items");
	vector<string> features = make_list(game, "features");
	cout << "Before neighbors list" << endl;
	vector<string> neighbors = make_list(game, "neighbors");
	cout << "After neighbors list" << endl;

	if (verb == "look at") {
		if (nType == "none") {
			//Nothing to look at
			return "INVAL:Please specify something to look at.";
		} else if (!is_in(items, noun) && !is_in(features, noun) && !is_in(neighbors, noun) && !is_in(inventory, noun)) {
			//Trying to look at something that isn't in currRoom
			return "INVAL:That isn't around right now.";
		} else {
			//Valid
			return verb + ":" + noun;
		}
	} else if (verb == "look") {
		//Ignore nouns, since look doesn't need one
		return verb + ":NONE";
	} else if (verb == "go" || verb == "") {
		if (nType != "place") {
			if (verb == "") {
				//Non place noun with no verb
				return "INVAL:No command recognized. Use the 'help' command for examples of acceptable commands.";
			} else {
				//'go' with no destination
				return "INVAL:You must specify somewhere you can go.";
			}
		} else if (!is_in(neighbors, noun)) {
			//Trying to go to non-neighboring room
			return "INVAL:You can't get there from here.";
		} else { 
			//Valid
			return "go:" + noun;	
		}
	} else if (verb == "take") {
		if (nType == "feature" || nType == "place") {
			//Trying to pick something up that isn't an item
			return "INVAL:You can't take that with you.";
		} else if (nType == "none") {
			//No noun specified
			return "INVAL: What do you want to pick up?";
		} else {
			//Picking up item
			if (is_in(inventory, noun)) {
				//Item already in inventory
				return "INVAL:You're already holding that.";
			} else if (!is_in(items, noun)) {
				//Item not in currRoom
				return "INVAL:That isn't around right now.";
			} else {
				//Valid
				return verb + ":" + noun;
			}
		}
	} else if (verb == "drop") {
		if (nType == "feature" || nType == "place") {
			//Trying to drop feature or door
			return "INVAL:You can't drop something that you can't hold.";
		} else if (nType == "none") {
			//No noun specified
			return "INVAL: What do you want to drop?";
		} else {
			//Dropping item
			if (!is_in(inventory, noun)) {
				//Trying to drop something not in inventory
				return "INVAL:You can't drop something you aren't holding.";
			} else {
				//Valid
				return verb + ":" + noun;
			}
		}
	} else if (verb == "use") {
		if (nType == "feature" || nType == "place") {
			//Trying to use something that can't be held
			return "INVAL:You can't use that.";
		} else if (nType == "none") {
			//No noun specified
			return "INVAL: What do you want to use?";
		} else {
			//Using item
			if (!is_in(inventory, noun)) {
				//Trying to use item not in inventory
				return "INVAL:You can't use something you aren't holding.";
			} else {
				//Valid
				return verb + ":" + noun;
			}
		}
	} else if (verb == "inventory") {
		//Ignore nouns, since inventory doesn't need one
		return verb + ":NONE";
	} else if (verb == "savegame") {
		//Ignore nouns, since savegame doesn't need one
		return verb + ":NONE";
	} else if (verb == "loadgame") {
		//Ignore nouns, since loadgame doesn't need one
		return verb + ":NONE";
	} else if (verb == "help") {
		//Ignore nouns, since help doesn't need one
		return verb + ":NONE";
	} else if (verb == "quit") {
		//Ignore nouns, since quit doesn't need one
		return verb + ":NONE";
	} else {
		return "INVAL:No command recognized. Use the 'help' command for examples of acceptable commands.";
	}
}

//Searches a vector for a given string
bool is_in(vector<string> list, string search) {
	if (find(list.begin(), list.end(), search) != list.end()) {
		return true;
	} else {
		return false;
	}
}

//Makes a vector of strings from a vector of objects
vector<string> make_list(Game* game, string type) {
	vector<string> list;
	Room* currRoom = game->getCurrentRoom();
	
	if (type == "inventory") {
		vector<Item> inventory = *(game->getInventoryList());
		
		for (int i = 0; i < static_cast<int>(inventory.size()); i++) {
			list.push_back(inventory[i].getName());
		}
	} else if (type == "items") {
		vector<Item*> items = currRoom->getItems();
		
		for (int i = 0; i < static_cast<int>(items.size()); i++) {
			list.push_back(items[i]->getName());
		}
	} else if (type == "features") {
		vector<RoomFeature*> features = currRoom->getRoomFeatures();
		
		for (int i = 0; i < static_cast<int>(features.size()); i++) {
			list.push_back(features[i]->getName());
		}
	} else if (type == "neighbors") {
		vector<Door*> doors = currRoom->getDoors();

		//TODO: Work on this after demo		
//		for (int i = 0; i < static_cast<int>(doors.size()); i++) {
//			cout << "i = " << i << endl;
//			if (currRoom == doors[i]->getConnectingRooms()[0]) {
//				list.push_back(doors[i]->getConnectingRooms()[1]->getRoomName());
//				cout << "Pushed back " << doors[i]->getConnectingRooms()[1]->getRoomName() << endl;
//			} else {
//				list.push_back(doors[i]->getConnectingRooms()[0]->getRoomName());
//				cout << "Pushed back " << doors[i]->getConnectingRooms()[0]->getRoomName() << endl;
//			}
//		}
//		cout << "After first loop" << endl;
//		
//		for (int i = 0; i < static_cast<int>(list.size()); i++) {
//			cout << list[i] << endl;
//		}
		
		for (int i = 0; i < static_cast<int>(doors.size()); i++) {
			list.push_back(doors[i]->getName());
		}
	}
	
	return list;
}
//
//  Character.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/21/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "Character.h"

//Set the character name
void Character::setCharacterName( string characterName )
{
    
}

//Set the character description.
void Character::setCharacterDescription( string characterDescription )
{
    
}

//Set friend or foe state
void Character::setIsFriend( bool isFriend )
{
    
}

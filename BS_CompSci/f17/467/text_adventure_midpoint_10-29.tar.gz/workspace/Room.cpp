//
//  Room.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "Room.h"
#include <iostream>

//Return the doors in the room.
vector<Door*> Room::getDoors()
{
    return doorsInRoom;
}

//Return the items in the room.
vector<Item*> Room::getItems( )
{
    return itemsInRoom;
}

//Return the room features.
vector<RoomFeature*> Room::getRoomFeatures( )
{
    return roomFeatures;
}

bool Room::getIsCurrentRoom( )
{
    return isCurrentRoom;
}

//Set the doors in the room.
void Room::setDoorsInRoom( Door* door )
{
    doorsInRoom.push_back( door );
}

//Set the items in the room.
void Room::setItem( Item* item )
{
    itemsInRoom.push_back( item );
}

//Set the items in the room.
void Room::setRoomFeature( RoomFeature* roomFeature )
{
    roomFeatures.push_back( roomFeature );
}

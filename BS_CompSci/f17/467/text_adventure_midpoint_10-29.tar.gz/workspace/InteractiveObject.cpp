//
//  Object.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "InteractiveObject.h"

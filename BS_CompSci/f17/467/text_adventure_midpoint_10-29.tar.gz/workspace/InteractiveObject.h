//
//  Object.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef INTERACTIVEOBJECT_H
#define INTERACTIVEOBJECT_H

#include <stdio.h>
#include <string>
//#include "Room.h"

using namespace std;

class Room;

class InteractiveObject
{
    
private:
    string name;
    string description;
    Room* pLoc;
    bool canInventory;
    
public:
    InteractiveObject( bool canInventory = false )
    {
        setCanInventory( canInventory );
    }
    
    string getName()
    {
        return name;
    }
    
    string getDescription()
    {
        return description;
    }
    
    Room* getLocation()
    {
        return pLoc;
    }
    
    bool getCanInventory()
    {
        return canInventory;
    }
    
    void setName(string name)
    {
        this->name = name;
    }
    
    void setDescription(string description)
    {
        this->description = description;
    }
    
    void setLocation(Room* pLoc)
    {
        this->pLoc = pLoc;
    }
    
    void setCanInventory(bool canInventory)
    {
        this->canInventory = canInventory;
    }
};

#endif 

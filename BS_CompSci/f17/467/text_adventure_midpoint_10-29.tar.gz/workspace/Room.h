//
//  Room.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef ROOM_H
#define ROOM_H

#include <stdio.h>
#include <vector>
#include <string>
#include "Door.h"
//#include "InteractiveObject.h"
#include "Item.h"
#include "RoomFeature.h"

using namespace std;

class Room
{
private:
    
    //Name of the room.
    string roomName;
    
    //Long-form description of the room.
    string longFormDescription;
    
    //Modified long-form description of the room.
    string modLongFormDescription;

    //Short-form description of the room.
    string shortFormDescription;
    
    //Modified short-form description of the room.
    string modShortFormDescription;
    
    //An additional explanation that will appear after the long or short-form.
    string additionalExplanation;
    
    //A vector containing all of the doors in the room.
    vector<Door*> doorsInRoom;
    
    //A list of items currently in the room that the user can take with them.
    vector<Item*> itemsInRoom;
    
    //A list of room features.
    vector<RoomFeature*> roomFeatures;
    
    //Is the user currently in this room.
    bool isCurrentRoom;
    
public:
    
    //Default constructor. Create one with parameters if needed.
    Room( bool isCurrentRoom = false )
    {
        setIsCurrentRoom( isCurrentRoom );
    }
    
    //Default destructor.
    //~Room();
    
    //Return the name of the room.
    string getRoomName()
    {
        return roomName;
    }
    
    //Return the long-form room description.
    string getLongFormDescrip()
    {
        return longFormDescription;
    }
    
    //Return the short-form room description.
    string getShortFormDescrip()
    {
        return shortFormDescription;
    }
    
    //Return the modified long-form room description.
    string getModLongFormDescrip()
    {
        return modLongFormDescription;
    }
    
    //Return the modified short-form room description.
    string getModShortFormDescrip()
    {
        return modShortFormDescription;
    }
    
    //Return the additional explanation.
    string getAdditionalExplanation()
    {
        return additionalExplanation;
    }
    
    //Return the number of doors in the room.
    unsigned long getNumDoors()
    {
        return doorsInRoom.size();
    }
    
    //Return the doors in the room.
    vector<Door*> getDoors();
    
    //Return the items in the room.
    vector<Item*> getItems();
    
    //Return the features of the room.
    vector<RoomFeature*> getRoomFeatures();
    
    //Return the current room state.
    bool getIsCurrentRoom();
    
    //Set the room name.
    void setRoomName( string name )
    {
        roomName = name;
    }
    
    //Set the long-form room description.
    void setLongFormDescrip( string LFDescrip )
    {
        longFormDescription = LFDescrip;
    }
    
    //Set the short-form room description.
    void setShortFormDescrip( string SFDescrip )
    {
        shortFormDescription = SFDescrip;
    }
    
    //Set the modified long-form room description.
    void setModLongFormDescrip( string MLFDescrip)
    {
        modLongFormDescription = MLFDescrip;
    }
    
    //Set the modified short-form room description.
    void setModShortFormDescrip( string MSFDescrip)
    {
        modShortFormDescription = MSFDescrip;
    }
    
    //Set the additional explanation.
    void setAdditionalExplanation( string addExplan )
    {
        additionalExplanation = addExplan;
    }
    
    //Set the doors in the room.
    void setDoorsInRoom( Door* door );
    
    //Set the objects in the room.
    void setItem( Item* item );
    
    //Set the objects in the room.
    void setRoomFeature( RoomFeature* roomFeature );
    
    //Set if the room is the current room.
    void setIsCurrentRoom( bool isCurrentRoom )
    {
        this->isCurrentRoom = isCurrentRoom;
    }
    
};

#endif 

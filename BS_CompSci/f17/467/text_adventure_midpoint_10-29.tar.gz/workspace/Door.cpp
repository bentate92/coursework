//
//  Door.cpp
//  GameEngine
//
//  Created by Alan Seims on 10/21/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#include "Door.h"

Door::Door()
{
    state = unlocked;
}

//Set the door state.
void Door::setDoorState( int state )
{
    if( state == 0 )
    {
        this->state = unlocked;
    }
    else if( state == 1 )
    {
        this->state = locked;
    }
    else if( state == 2 )
    {
        this->state = blocked;
    }
    else
        cout << "Invalid door state read from file!" << endl;
}

//Set the connecting rooms.
void Door::setConnectingRooms( Room* connectingRoom )
{
    connectingRooms.push_back( connectingRoom );
}


#ifndef COMMAND_H
#define COMMAND_H

#include <stdio.h>
#include <vector>
#include <string>

using namespace std;

void section_command(string command, string* word1, string* word2);

string actionRoom(string verb, string noun, Room* curr_room, vector<string> inv, Game* game);

string command(Game* g, string command);

string validate(Game* game, string verb, string noun, string nType);

bool is_in(vector<string> list, string search);

vector<string> make_list(Game* game, string type);

#endif
//
//  spaceAdventure.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/22/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef SPACEADVENTURE_HELPERS_H
#define SPACEADVENTURE_HELPERS_H

#include <stdio.h>
#include <vector>
#include "Game.h"
#include "Door.h"
#include "Room.h"
#include "Item.h"
#include "RoomFeature.h"


using namespace std;

void gameInit( vector<Room> &rooms, vector<Item> &items, vector<Item> &inventory);
void loadRooms(vector<Room> &rooms, vector<Door> &doors, vector<Item> &items, vector<RoomFeature> &features);

#endif

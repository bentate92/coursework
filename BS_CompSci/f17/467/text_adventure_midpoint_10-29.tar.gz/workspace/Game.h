//
//  Game.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/5/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef GAME_H
#define GAME_H

#include <stdio.h>
#include <vector>
#include <string>
#include "InteractiveObject.h"
#include "Room.h"
#include "Door.h"
#include "Item.h"
#include "Character.h"

using namespace std;

class Game
{
private:
    
    //The rooms of the game.
    vector<Room>* gameRooms;
    
    //The current direction the user is facing.
    string currentDirection;
    
    //Current list of items in the user’s inventory.
    vector<Item>* inventoryList;
    
    //The current floor level that the user is on.
    string currentFloorLevel;
    
    //The current room that the user is in.
    Room* currentRoom;
    
    //The current spot of a room that the user is located.
    //***NOTE: May not be needed.
    string currentLocation;
    
    //A list of rooms the user has already visited.
    vector<Room> roomsVisited;
    
    //A list of locations for all of the game’s items.
    vector<string> itemLocations;
    
    
    
public:
    
    //default constructor, no parameters
    Game( );
    
    //Create an overloaded constructor with parameters if needed.
    Game( vector<Room> &rooms, vector<Item> &inventory );

    //destructor
    ~Game( );
    
    
    //Get the rooms in the game.
    vector<Room>* getGameRooms();
    
    //Get the current direction the user is facing.
    string getUserDirection( )
    {
        return currentDirection;
    }
    
    //Get the user’s inventory list.
    vector<Item>* getInventoryList( )
    {
        return inventoryList;
    }
    
    //Get the current floor level that the user is on.
    string getCurrentFloorLevel( )
    {
        return     currentFloorLevel;
    }
    
    //Get the current room that the user is currently in.
    Room* getCurrentRoom( )
    {
        return currentRoom;
    }
    
    //Get the current location of the user within a room.
    string getCurrentLocation( )
    {
        return currentLocation;
    }
    
    //Get the rooms the user has already visited.
    const vector<Room> getRoomsVisited( )
    {
        return roomsVisited;
    }
    
    //Get the locations for all of the game’s objects.
    const vector<string> getObjectLocations( )
    {
        return itemLocations;
    }
    
    
    //Set the rooms in the game.
    void setGameRooms( vector<Room> &room );
    
    //Set the current direction the user is facing.
    void setUserDirection( string userDirection );
    
    //Set the user’s inventory list.
    void setInventoryList( Item* inventoryItem );
    
    //Set the current floor level that the user is on.
    void setCurrentFloorLevel( string currentFloorLevel );
    
    //Set the current room that the user is currently in.
    void setCurrentRoom( Room* currentRoom);
    
    //Set the current location of the user within a room.
    void setCurrentLocation( string currentLocation);
    
    //Set the rooms the user has already visited.
    void setRoomsVisited( Room visitedRooms );
    
    //Set the locations for all of the game’s objects.
    void setItemLocations( string itemLocation );
    
};

#endif 

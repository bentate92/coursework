//
//  Door.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/21/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef DOOR_H
#define DOOR_H

#include <stdio.h>
#include <iostream>
#include <vector>
#include <string>
#include "InteractiveObject.h"

using namespace std;

class Door : public InteractiveObject
{
public:
    //Door status
    enum doorState { unlocked, locked, blocked };
    
private:
    //Door state.
    doorState state;
    
    //Connecting rooms.
    vector<Room*> connectingRooms;
    
public:
    //default constructor. Create one with parameters if needed.
    Door();
        
    //Default destructor.
    //~Door();
    
    //Get the door state.
    doorState getDoorState()
    {
        return state;
    }
    
    //Get the connecting rooms
    vector<Room*> getConnectingRooms( )
    {
        return connectingRooms;
    }

    
   //Set the door state.
    void setDoorState( int state );
    
    
    //Set the connecting room.
    void setConnectingRooms( Room* connectingRoom );
    
};

#endif

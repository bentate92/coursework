//
//  Item.hpp
//  GameEngine
//
//  Created by Alan Seims on 10/21/17.
//  Copyright © 2017 Alan Seims. All rights reserved.
//

#ifndef ITEM_H
#define ITEM_H

#include <stdio.h>
#include <string>
#include "InteractiveObject.h"

using namespace std;

class Item : public InteractiveObject
{
private:
    string itemUse;

public:
    void setItemUse( string itemUse )
    {
        this->itemUse = itemUse;
    }
};

#endif

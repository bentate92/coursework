/*****************************************************************************************
* Name: Benjamin Tate
* Date: 12/2/2016
* Class: CS 344
* Assignment: Program 4
* Description: Simple program to randomly generate a key file
******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char** argv) {
	//String to hold random cipher
	char cipher;
	//Int to hold key length argument
	int len;

	//Seed rand()
	srand(time(NULL));

	//Check for appropriate number of arguments
	if(argc < 2) {
       fprintf(stderr, "ERROR: not enough arguments (Usage: keygen <key length>)\n", argv[0]);
		exit(1);
	}

	//Set length and check validity
	sscanf(argv[1], "%d", &len);
	if(len < 1) {
		fprintf(stderr, "ERROR: key length argument must be greater than zero\n");
		exit(1);
	}

	int i;							//Declare loop iterator
	//Repeat for length of key
	for(i = 0; i < len; i++) {
		//Set random cipher character between 64 and 90, inclusive
		cipher = (char)(rand() % 27 + 64);

		//Replace @s with spaces
		if(cipher == '@') {
			cipher = ' ';
		}

		//Print cipher character
		printf("%c", cipher);
	}
	//End with newline
	printf("\n");

	return 0;
}

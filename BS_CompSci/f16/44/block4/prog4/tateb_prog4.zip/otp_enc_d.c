/*****************************************************************************************
* Name: Benjamin Tate
* Date: 12/2/2016
* Class: CS 344
* Assignment: Program 4
* Description: Program to connect to otp_enc for encryption of given plaintext, using the
*	given key
******************************************************************************************/

#include <fcntl.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define BUFFER 100000

int main(int argc, char** argv) {
	int port;						//Int to hold port number argument
	int pid;						//Int to hold process id
	int sock1;						//First socket file descriptor
	int sock2;						//Second socket file descriptor
	int sent;						//Int to hold length of sent message
	int keyLen;						//Length of key
	int ptLen;						//Length of plaintext file

	//Strings to hold plaintext, key, and encoded text
	char buff1[BUFFER];
	char buff2[BUFFER];
	char buff3[BUFFER];

	struct sockaddr_in s;			//Server address struct
	struct sockaddr_in c;			//Client address struct
	socklen_t cLen;					//Size of client address

	//Check for appropriate argument count
	if(argc < 2) {
		fprintf(stderr, "ERROR: not enough arguments (Usage: otp_enc_d <port>)\n");
		exit(1);
	}

	//Set port number and check validity
	sscanf(argv[1], "%d", &port);
	if(port < 0 || port > 65535) {
		fprintf(stderr, "ERROR: invalid port number for otp_enc_d\n");
		exit(2);
	}

	//Create first socket on given port
	if((sock1 = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, "ERROR: otp_enc_d was unable to create a socket\n");
		exit(1);
	}

	//Set all characters of s to NULL
	memset(&s, '\0', sizeof(s));

	//Set s to AF_INET family
	s.sin_family = AF_INET;
	//Set s's s_addr
	s.sin_addr.s_addr = INADDR_ANY;
	//Set s's sin_port
	s.sin_port = htons(port);

	//Bind socket
	if(bind(sock1, (struct sockaddr*)&s, sizeof(s)) < 0) {
		fprintf(stderr, "ERROR: otp_enc_d was unable to bind socket\n");
		exit(2);
	}

	//Listen for incoming connections
	if(listen(sock1, 5) == -1) {
		fprintf(stderr, "ERROR: otp_enc_d failed to listen on port %d\n", port);
		exit(2);
	}

	//Set cLen
	cLen = sizeof(c);

	//Continue until terminated
	while(1) {
		//Accept incoming connections from sock1 as sock2
		sock2 = accept(sock1, (struct sockaddr*)&c, &cLen);
		if(sock2 < 0) {
			fprintf(stderr, "ERROR: otp_enc_d failed to accept connection\n");
			continue;
		}

		//Fork process and check success
		pid = fork();
		if(pid < 0) {
			fprintf(stderr, "ERROR: otp_enc_d fork issues\n");
		}

		//If fork success
		if(pid == 0) {
			//Zero out buff1
			memset(buff1, 0, BUFFER);

			//Declare handshake string and read from socket
			char handshake[3];
			read(sock2, handshake, 3);
			//Make sure that otp_dec isn't the one that is connected
			if(strcmp(handshake, "dec") == 0) {
				fprintf(stderr, "ERROR: otp_dec is not allowed to connect to otp_enc_d\n");
				exit(1);
			}

			//Read buff1 from sock2 and set ptLen
			ptLen = read(sock2, buff1, BUFFER);
			//Check read success
			if(ptLen < 0) {
				fprintf(stderr, "ERROR: otp_enc_d unable to read plaintext file\n");
				exit(2);
			}

			//Send acknowledgement and check success
			sent = write(sock2, "*", 1);
			if(sent < 0) {
				fprintf(stderr, "ERROR: otp_enc_d failed to send acknowledgement\n");
				exit(2);
			}

			//Zero out buff2
			memset(buff2, 0, BUFFER);

			//Read buff2 from socket and set keyLen
			keyLen = read(sock2, buff2, BUFFER);
			//Check success of read
			if(keyLen < 0) {
				fprintf(stderr, "ERROR: otp_enc_d unable to read key file\n");
				exit(2);
			}

			int i;					//Declare loop iterator		
			//Check entire plaintext file for invalid characters
			for(i = 0; i < ptLen; i++) {
				if((int)buff1[i] > 90 || ((int)buff1[i] < 65 && (int)buff1[i] != 32)) {
					fprintf(stderr, "ERROR: plaintext file contains invalid characters\n");
					exit(1);
				}
			}

			//Check entire key file for invalid characters
			for(i = 0; i < keyLen; i++) {
				if((int)buff2[i] > 90 || ((int)buff2[i] < 65 && (int)buff2[i] != 32)) {
					fprintf(stderr, "ERROR: key file contains bad characters\n");
					exit(1);
				}
			}
			
			//Repeat for each character of plaintext file
			for(i = 0; i < ptLen; i++) {
				//Replace spaces with @s (to make all ascii characters used adjacent)
				if(buff1[i] == ' ') {
					buff1[i] = '@';
				}

				//Do the same for the key
				if(buff2[i] == ' ') {
					buff2[i] = '@';
				}

				//Set ints to hold decimal value of each character
				int msg = (int)buff1[i];
				int key = (int)buff2[i];

				//Subtract 64 to make numbers 0-26
				msg -= 64;
				key -= 64;

				//Set cipher using mod 27 of sum of key and msg
				int cipher = (msg + key) % 27;

				//Add 64 back to cipher
				cipher += 64;

				//Add cipher to buff3 (encoded string)
				buff3[i] = (char)cipher + 0;

				//Put spaces back in place of @s
				if(buff3[i] == '@') {
					buff3[i] = ' ';
				}
			}

			//Send encoded message and check success
			sent = write(sock2, buff3, ptLen);
			if(sent < ptLen) {
				fprintf(stderr, "ERROR: otp_enc_d write issues\n");
				exit(2);
			}

			//Close sockets
			close(sock2);
			close(sock1);

			//Exit loop
			exit(0);
		} else {
			//Fork failed, close sock2
			close(sock2);
		}
	}

	return 0;
}

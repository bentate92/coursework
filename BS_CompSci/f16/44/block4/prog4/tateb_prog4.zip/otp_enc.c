/*****************************************************************************************
* Name: Benjamin Tate
* Date: 12/2/2016
* Class: CS 344
* Assignment: Program 4
* Description: Program to connect to otp_enc_d for encryption of given plaintext, using
*	the given key
******************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h> 
#include <fcntl.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>

#define BUFFER 100000

int main(int argc, char** argv) {
	int port;						//Int to hold port number argument
	int file;						//File descriptor
	int sock;						//Socket file descriptor
	int sent;						//Int to hold sent length
	int received;					//Int to hold received length
	int keyLen;						//Length of key
	int ptLen;						//Length of plaintext file

	//Strings to hold plaintext and key files
	char buff1[BUFFER];				
	char buff2[BUFFER];				
	//String to hold acknowledgement character
	char buff3[1];					

	struct sockaddr_in sAddr;		//Server address struct
	struct hostent* s;				//Pointer to server hostent

	//Check for appropriate argument count
	if(argc < 4) {
		fprintf(stderr, "ERROR: not enough arguments (Usage: otp_enc <plaintext> <key> <port>)\n");
		exit(1);
	}

	//Set port number and check validity
	sscanf(argv[3], "%d", &port);
	if(port < 0 || port > 65535) {
		fprintf(stderr, "ERROR: invalid port number for otp_enc\n");
		exit(2);
	}

	//Open plaintext file in read mode and check success
	file = open(argv[1], O_RDONLY);
	if(file < 0) {
		fprintf(stderr, "ERROR: unable to open plaintext file %s\n", argv[1]);
		exit(1);
	}

	//Set ptLen based on file length, and read file into buff1
	ptLen = read(file, buff1, BUFFER);

	int i;							//Declare loop iterator
	//Check entire file for invalid characters
	for(i = 0; i < ptLen - 1; i++) {
		if((int)buff1[i] > 90 || ((int)buff1[i] < 65 && (int)buff1[i] != 32)) {
			fprintf(stderr, "ERROR: plaintext file contains invalid characters\n");
			exit(1);
		}
	}

	//Close plaintext file
	close(file);

	//Open key file in read mode and check success
	file = open(argv[2], O_RDONLY);
	if(file < 0) {
		fprintf(stderr, "ERROR: unable to open key file %s\n", argv[2]);
		exit(1);
	}

	//Set keyLen based on file length, and read key into buff2
	keyLen = read(file, buff2, BUFFER);

	//Check entire key for invalid characters
	for(i = 0; i < keyLen - 1; i++) {
		if((int)buff2[i] > 90 || ((int)buff2[i] < 65 && (int)buff2[i] != 32)) {
			fprintf(stderr, "ERROR: key file contains invalid characters\n");
			exit(1);
		}
	}

	//Close key
	close(file);

	//Check that keyLen is not less than ptLen
	if(keyLen < ptLen) {
		fprintf(stderr, "ERROR: key file is too short\n");
		exit(1);
	}

	//Create socket on given port
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if(sock < 0) {
		fprintf(stderr, "ERROR: otp_enc was unable to contact otp_enc_d on port %d\n", port);
		exit(2);
	}

	//Set all characters of sAddr to NULL characters
	memset(&sAddr, '\0', sizeof(sAddr));

	//Initialize hostent and check success
	s = gethostbyname("localhost");
	if(s == NULL) {
		fprintf(stderr, "ERROR: otp_enc was unable to contact otp_enc_d\n");
		exit(2);
	}    

	//Set sAddr to AF_INET family
	sAddr.sin_family = AF_INET;
	//Copy server's h_addr into sAddr
	bcopy((char*)s->h_addr, (char*)&sAddr.sin_addr.s_addr, s->h_length);         
	//Set sAddr sin_port
	sAddr.sin_port = htons(port);

	//Begin connection and check success
	if(connect(sock, (struct sockaddr*)&sAddr, sizeof(sAddr)) < 0) {
		fprintf(stderr, "ERROR: otp_enc was unable to contact otp_enc_d on port %d\n", port);
		exit(2);
	}

	//Send handshake to make sure otp_dec_d is not connected
	write(sock, "enc", 3);

	//Send plaintext to otp_enc_d and check success
	sent = write(sock, buff1, ptLen - 1);
	if(sent < ptLen - 1) {
		fprintf(stderr, "ERROR: unable to send plaintext file to otp_enc_d\n");
		exit(2);
	}

	//Zero out buff3
	memset(buff3, 0, 1);

	//Read acknowledgement message into buff3 and check success
	received = read(sock, buff3, 1);
	if(received < 0) {
		fprintf(stderr, "ERROR: otp_enc did not receive acknoledgement from otp_enc_d\n");
		exit(2);
	}

	//Send key to otp_enc_d and check success
	sent = write(sock, buff2, keyLen - 1);
	if(sent < keyLen - 1) {
		fprintf(stderr, "ERROR: otp_enc unable to send key file to otp_enc_d\n");
		exit(2);
	}

	//Zero out buff1
	memset(buff1, 0, BUFFER);

	//Read ciphertext into buff1
	do {
		received = read(sock, buff1, ptLen - 1);
	} while(received > 0);

	//Check success of ciphertext read
	if(received < 0) {
		fprintf(stderr, "ERROR: otp_enc did not receive ciphertext file from otp_enc_d\n");
		exit(2);
	}

	//Print encoded message
	for(i = 0; i < ptLen - 1; i++) {
		printf("%c", buff1[i]);
	}
	//End with newline
	printf("\n");

	//Close socket
	close(sock);

	return 0;
}

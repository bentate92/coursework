/**********************************************************************************
 * Name: Benjamin Tate
 * Date: 10/30/2016
 * Class: CS372
 * Assignment: Project 1
 * Description: Client-side implementation of a simple chat application between two
 *   separate machines
 **********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

int main(int argc, char *argv[]) {
	//Initialize ints to hold socket, port number, and payloads
    int s;
	int port;
	int n;

	//Initialize strings to hold handles of client and server
	char cHandle[11];
	char sHandle[11];

	//Initialize string to hold messages
    char message[501];

	//Initialize server sockaddr_in structure
    struct sockaddr_in sAddress;
	//Initialize hostent struct pointer
    struct hostent *server;

	//Check for correct number of arguments
    if (argc < 3) {
       fprintf(stderr, "ERROR: not enough arguments (usage %s hostname port)\n", argv[0]);
       exit(1);
    }

	//Get handle from client and remove newline character from end
	printf("Input Handle: ");
	fgets(cHandle, 10, stdin);
	strtok(cHandle, "\n");
	
	//Convert port argument to an int
    port = atoi(argv[2]);

	//Create socket and check success
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        fprintf(stderr, "ERROR: could not open socket");
		exit(1);
	}

	//Assign host name argument to server hostent
    server = gethostbyname(argv[1]);
	//Check that host exists, throw error if not//
    if (server == NULL) {
        fprintf(stderr, "ERROR: no such host\n");
        exit(1);
    }

	//Fill sAddress with zeros
    bzero((char *) &sAddress, sizeof(sAddress));
	//Set sAddress family to match socket
    sAddress.sin_family = AF_INET;
	//Copy server's host address into sAddress
    bcopy((char *)server->h_addr, 
         (char *)&sAddress.sin_addr.s_addr,
         server->h_length);
	//Set sAddress' port
    sAddress.sin_port = htons(port);
	//Attempt to connect to server and throw error if failed
    if (connect(s, (struct sockaddr*) &sAddress, sizeof(sAddress)) < 0) {
        fprintf(stderr, "ERROR connecting");
		exit(1);
	}

	//Fill server handle with zeros, then fill from first message from server
	bzero(sHandle, 11);
	n = read(s, sHandle, 11);
	//Check success of read()
	if(n < 0) {
		fprintf(stderr, "ERROR reading from socket");
		exit(1);
	}

	//Print message that connection was successful
	printf("Connection established to: %s\n\n", sHandle);

	//Send client handle to server
	n = write(s, cHandle, strlen(cHandle));
	//Check success of write()
	if(n < 0) {
		fprintf(stderr, "ERROR reading from socket");
		exit(1);
	}

	//Continue while message exists
	while(message) {
		//Print cHandle as prompt for message
	    printf("%s> ", cHandle);

		//Empty message
	    bzero(message, 501);
		//Get message from keyboard
	    fgets(message, 500, stdin);
		//Remove trailing newline from message
		strtok(message, "\n");

		//If message is \quit, send to server and break
		if(strcmp(message, "\\quit") == 0) {
			n = write(s, message, strlen(message));
			break;
		}
		//Otherwise, send message to server
	    n = write(s, message, strlen(message));
		//Check success of write()
	    if (n < 0) {
	         fprintf(stderr, "ERROR writing to socket");
			 exit(1);
		}

		//Empty message
	    bzero(message, 501);
		//Read message from server
	    n = read(s, message, 501);
		//Check success of read()
	    if (n < 0) {
	         fprintf(stderr, "ERROR reading from socket");
			 exit(1);
		}
		//If server sent \quit, inform client and break
		if(strcmp(message, "\\quit") == 0) {
			printf("Server %s closed the connection.", sHandle);
			break;
		}
		//Otherwise, print server's message
	    printf("%s> %s\n", sHandle, message);
	}

	//Close connection and return
    close(s);
    return 0;
}

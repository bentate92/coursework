##################################################################################
# Name: Benjamin Tate
# Date: 10/30/2016
# Class: CS372
# Assignment: Project 1
# Description: Server-side implementation of a simple chat application between two 
#   separate machines
##################################################################################

import sys
import socket

#Check for appropriate number of arguments and exit if not received
if len(sys.argv) < 2:
	sys.stderr.write('ERROR: no port provided\n')
	sys.exit(1)

#Get handle from server
sHandle = raw_input("Input Handle: ")

#Create socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#Set host name and port number of server
host = socket.gethostname()
port = int(sys.argv[1])

#Bind host name and port to socket
s.bind((host, port));

#Wait for connection from client
s.listen(5)

#Loop until SIGINT received
while True:
	#Accept connection with client
	c, addr = s.accept()

	#Send server handle to client
	c.sendall(sHandle)

	#Receive client handle from client
	cHandle = c.recv(11)

	#If cHandle was received, print connection message
	if cHandle:
		print 'Connection established to: {0}\n'.format(cHandle)

	try:
		#Continue messaging until SIGINT received
		while True:
			#Client messages first
			cMessage = c.recv(501)
	
			#If message received from client...
			if cMessage:
				#If client did not close the connection...
				if cMessage != "\quit":
					#Print cHandle and cMessage
					print '{0}> {1}'.format(cHandle, cMessage)

					#Get sMessage from keyboard and send to client
					sMessage = raw_input("{0}> ".format(sHandle))
					c.sendall(sMessage)
				#Otherwise, print message that client closed connection
				else:
					print 'Client {0} closed the connection.'.format(cHandle)
			#Otherwise, connection was closed, so break
			else:
				break
	#Close connection in case of error
	finally:
		c.close()


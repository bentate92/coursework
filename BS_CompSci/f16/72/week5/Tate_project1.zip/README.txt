+--------------------------------------------------------------------------------+
| Name: Benjamin Tate															 |
| Date: 10/30/2016																 |
| Class: CS372																	 |
| Assignment: Project 1															 |
| Description: README file for chatserve.py and chatclient.c					 |
| Testing: This project was tested on access.engr.orst.edu, with chatclient		 |
|	running on flip1 and chatserve running on flip2								 |
+--------------------------------------------------------------------------------+

COMPILING: 
 - To compile and run chatserve, use the following command:
		python chatserve.py <port>
   where <port> represents the port you would like to host the chat on

 - To compile and run chatclient, use the following command:
		gcc -o chatclient chatclient.c 
   and then run with:
		./chatclient <host> <port>
   where <host> is the name of the machine that is running chatserve, and <port>
   is the port number that chatserve is running on

 - Notes:
	* Make sure that chatserve is running and server handle has been input before 
	  you run chatclient
	* Only run one chatclient at a time per chatserve. Any chatclients run after
	  the first will simply sit idle.
	* It is recommended that the included Makefile is used for multiple runs.
	  However, make note of the machine that chatserve is being run on and change
	  the client command accordingly. Port numbers in each command may need to 
	  be changed as well if default ports are in use.
	* After Makefile is properly altered as described above, chatserve can be 
	  compiled and run with:
		  make server
	  and chatclient can be compiled and run (in a separate window) with:
		  make client

USE:
 - Upon running chatserve, a prompt will be shown for the server handle. The
   handle must not include spaces and must not exceed 10 characters.
 - After inputting handle, the server will wait for a connection. In a separate
   window, compile and run chatclient as described above.
 - Once run, chatclient will display an identical handle prompt. The client handle
   must also be no more than 10 characters, with no spaces.
 - After inputting the client handle, a connection should be established, and the
   client and server will exchange handles (this will be indicated by a message on 
   each window).
	* Note: The client and server only exchange handles once, rather than 
		prepending their handles to each of their own messages. In other words, the
		server will hold the client handle and prepend it to the client's messages,
		and the client will hold onto the server handle and prepend it to the
		server's messages. This was done to make string manipulation easier, and 
		to make hard-coded character limits more clear within chatclient.c
 - The client and server must take turns sending messages up to 500 characters. 
   Sending a message out of order (i.e. sending 2 in a row) will result in your 
   message being sent after the next message is received.
 - This will continue until either the client or server sends the message "\quit",
   which will cause the client to close the connection.
 - After the connection is closed, the server will return to waiting for a client
   connection.
 - To quit chatserve, first close the connection with \quit, and then press Ctrl-C 
   on the server window.

WEBSITES REFERENCED:
 - http://www.tutorialspoint.com/python/python_networking.htm
 - http://www.linuxhowtos.org/C_C++/socket.htm
 - https://pymotw.com/2/socket/tcp.html

 ***Code found on above references was used for inspiration only, and was heavily
    adapted to fit the needs of the this project


